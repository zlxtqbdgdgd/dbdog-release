# (C) Datadog, Inc. 2026-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
"""Collect completed slow SQL from ``dbe_perf.statement_history`` as DBM events.

This is the DBM-native path, modelled on the three engines that already ship a
completed-query stream:

* ClickHouse ``query_completions.py`` — historical table + persistent cursor, batched
  ``query_completion`` payload on the dbm-activity track.
* SQL Server ``xe_collection`` — engine-prefixed batch key, cursor advanced only to the
  last row actually read.
* Oracle ``statements.go`` — execution plans read from an engine-stored column rather
  than produced by running EXPLAIN.

Two differences from ClickHouse are deliberate and engine-driven:

* No per-signature sample rate limiting. openGauss decides slowness itself via
  ``is_slow_sql`` / ``slow_sql_threshold``, so rows arriving here are already filtered;
  re-sampling would drop consecutive degradations of the same query. ClickHouse has to
  sample because ``system.query_log`` holds every execution, slow or not.
* No EXPLAIN. ``query_plan`` is the plan the engine actually used, so re-planning would
  both cost the database and risk reporting a plan that never ran.
"""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Iterable

import psycopg
from cachetools import TTLCache
from psycopg.rows import dict_row

from datadog_checks.base.utils.common import to_native_string
from datadog_checks.base.utils.db.sql import compute_exec_plan_signature, compute_sql_signature
from datadog_checks.base.utils.db.utils import (
    DBMAsyncJob,
    default_json_event_encoding,
    obfuscate_sql_with_metadata,
)
from datadog_checks.base.utils.serialization import json
from datadog_checks.base.utils.tracking import tracked_method
from datadog_checks.opengauss.config_models import InstanceConfig
from datadog_checks.opengauss.statement_samples import agent_check_getter

try:
    import datadog_agent
except ImportError:
    from datadog_checks.base.stubs import datadog_agent

if TYPE_CHECKING:
    from datadog_checks.opengauss import OpenGauss

# Columns present in dbe_perf.statement_history but deliberately not selected: unbounded
# text blobs and driver-side timings that carry no analysis value on the wire.
STATEMENT_HISTORY_SKIP_COLUMNS = frozenset(
    {
        "net_send_info",
        "net_recv_info",
        "net_stream_send_info",
        "net_stream_recv_info",
        "details",
        "driver_info",
        "kernel_info",
        "driver_start_time",
        "driver_wait_response",
        "driver_finish_time",
    }
)

# The **superset** of columns worth shipping — not any one engine's real column set.
#
# Why no fixed list works: the shape of dbe_perf.statement_history differs per engine and
# per version. Read-only comparison on 2026-08-09:
#   openGauss 7.0.0-RC1 (ecs-8ea7 :5434) — 71 columns
#   GaussDB (vm202, measured 2026-08-02) — 72 columns
# openGauss lacks 14 of GaussDB's (finish_status, used_memory, sql_hash, plan_hash,
# plan_hash_prev, parent_unique_sql_id, relids, adaptive_join_states, aplan_*,
# lock_max_{local,fastpath,global}_count) and in exchange has its own srt1..srt14 +
# rtt_unknown response-time breakdown plus net_send_time, net_trans_time, parent_query_id.
#
# Hardcoding either list makes the SELECT fail with "column does not exist" on the other
# engine — and that error is classified as an expected DB exception, so the job logs a
# warning, counts it, and keeps looping: the stream stays empty without ever failing loudly.
# The real column set is therefore discovered at runtime and intersected with this superset.
STATEMENT_HISTORY_DESIRED_COLUMNS = [
    "db_name",
    "schema_name",
    "origin_node",
    "user_name",
    "application_name",
    "client_addr",
    "client_port",
    "unique_query_id",
    "debug_query_id",
    "query",
    "start_time",
    "finish_time",
    "slow_sql_threshold",
    "transaction_id",
    "thread_id",
    "session_id",
    "n_soft_parse",
    "n_hard_parse",
    "query_plan",
    "n_returned_rows",
    "n_tuples_fetched",
    "n_tuples_returned",
    "n_tuples_inserted",
    "n_tuples_updated",
    "n_tuples_deleted",
    "n_blocks_fetched",
    "n_blocks_hit",
    "db_time",
    "cpu_time",
    "execution_time",
    "parse_time",
    "plan_time",
    "rewrite_time",
    "pl_execution_time",
    "pl_compilation_time",
    "data_io_time",
    "lock_count",
    "lock_time",
    "lock_wait_count",
    "lock_wait_time",
    "lock_max_count",
    "lwlock_count",
    "lwlock_wait_count",
    "lwlock_time",
    "lwlock_wait_time",
    "is_slow_sql",
    "trace_id",
    "advise",
    "parent_unique_sql_id",
    "finish_status",
    "used_memory",
    "lock_max_local_count",
    "lock_max_fastpath_count",
    "lock_max_global_count",
    "sql_hash",
    "plan_hash",
    "plan_hash_prev",
    "adaptive_join_states",
    "aplan_count",
    "aplan_execution_time",
    "aplan_parse_time",
    "relids",
    # openGauss-only (7.0.0-RC1, live-read 2026-08-09). Its answer to "which stage was slow"
    # is this response-time breakdown rather than GaussDB's aplan_* / plan_hash columns.
    "parent_query_id",
    "net_send_time",
    "net_trans_time",
    "srt1_q",
    "srt2_simple_query",
    "srt3_analyze_rewrite",
    "srt4_plan_query",
    "srt5_light_query",
    "srt6_p",
    "srt7_b",
    "srt8_e",
    "srt9_d",
    "srt10_s",
    "srt11_c",
    "srt12_u",
    "srt13_before_query",
    "srt14_after_query",
    "rtt_unknown",
]

# 引擎归属备忘，供日志与 skill 用；不参与 SQL 构造（真实可用列一律运行期取交集）。
GAUSSDB_ONLY_COLUMNS = frozenset(
    {
        "parent_unique_sql_id",
        "finish_status",
        "used_memory",
        "lock_max_local_count",
        "lock_max_fastpath_count",
        "lock_max_global_count",
        "sql_hash",
        "plan_hash",
        "plan_hash_prev",
        "adaptive_join_states",
        "aplan_count",
        "aplan_execution_time",
        "aplan_parse_time",
        "relids",
    }
)

OPENGAUSS_ONLY_COLUMNS = frozenset(
    {
        "parent_query_id",
        "net_send_time",
        "net_trans_time",
        "rtt_unknown",
    }
    | {"srt1_q", "srt2_simple_query", "srt3_analyze_rewrite", "srt4_plan_query", "srt5_light_query"}
    | {"srt6_p", "srt7_b", "srt8_e", "srt9_d", "srt10_s", "srt11_c", "srt12_u"}
    | {"srt13_before_query", "srt14_after_query"}
)

# Columns promoted onto the top level of query_details, so they are not duplicated in the
# engine-native block.
PROMOTED_COLUMNS = frozenset(
    {
        "db_name",
        "user_name",
        "application_name",
        "client_addr",
        "client_port",
        "query",
        "query_plan",
        "start_time",
        "finish_time",
        "debug_query_id",
    }
)

STATEMENT_HISTORY_QUERY = (
    "SELECT {columns} FROM dbe_perf.statement_history "
    "WHERE is_slow_sql = true AND finish_time > %s "
    "ORDER BY finish_time ASC LIMIT %s"
)

# ── 引擎侧前置条件 ──
#
# 这条流有两个前置条件，且**最容易踩的那个不是档位**。
#
# 1) instr_unique_sql_count（默认 100，官方建议 200000）。分阶段耗时（db_time / cpu_time /
#    parse_time / plan_time / data_io_time / srt1..srt14 / rtt_unknown）全部来自内核的
#    timeModel[]，只在 unique-SQL 路径里搬进 handle；而 UpdateUniqueSQLStat() 在 unique SQL
#    哈希表达到 instr_unique_sql_count 时整个函数直接 return。表满之后：耗时列恒 0，且
#    query 被回填成一句提示串（MISSING_SQL_HINT）而不是真 SQL。
#    2026-08-09 在 7.0.0-RC1 实测：dbe_perf.statement 正好 100 条（打满），29752 行里
#    分阶段耗时仅 132 行（≈0.4%，恰对应 100 个槽位）有值，且 query 里能查到那句提示串。
#
# 2) track_stmt_stat_level 的慢 SQL 档位。**L0 就够**——官方 STATEMENT_HISTORY 字段表把
#    query / query_plan / 全部分阶段耗时 / srt* 都标为 L0，71 列里只有 4 个锁耗时列要 L1、
#    只有 details 的锁事件流要 L2；《例行维护》给出的唯一官方推荐值也正是 'L0,L0'。
#    所以这里只在档位为 OFF（连行都不写）时警告，不为 L0 报警。
#    版本差异：5.0.x 及更早的 query_plan 需要 L1，6.0.0 起降到 L0。
STAT_LEVEL_QUERY = "SHOW track_stmt_stat_level"
UNIQUE_SQL_COUNT_QUERY = "SHOW instr_unique_sql_count"
UNIQUE_SQL_OCCUPANCY_QUERY = "SELECT count(*) FROM dbe_perf.statement"

# 慢 SQL 档位为 OFF 时 statement_history 一行都不会写。
INSUFFICIENT_SLOW_STAT_LEVELS = frozenset({"OFF"})

# unique SQL 槽位打满时内核回填进 query 的提示串（instr_unique_sql.cpp 的 FindCurrentUniqueSQL）。
# 这不是 SQL，拿它算签名会让所有行塌成同一个签名。
MISSING_SQL_HINT = "missing SQL statement"

# 占用率达到这个比例就提醒：打满前就该扩，满了之后已经在丢数据。
UNIQUE_SQL_OCCUPANCY_WARN_RATIO = 0.9


def slow_stat_level(setting: str) -> str:
    """从 '<full>,<slow>' 取慢 SQL 档位；形态不认识时返回原串交由调用方判断。"""
    parts = [p.strip().upper() for p in (setting or "").split(",")]
    return parts[1] if len(parts) == 2 else (setting or "").strip().upper()


def is_missing_sql_hint(query: str) -> bool:
    """query 是否内核在 unique SQL 槽位打满时回填的提示串，而不是真 SQL。"""
    return MISSING_SQL_HINT in (query or "")


def looks_like_json_plan(plan: str) -> bool:
    """query_plan 是否 JSON —— 按**能不能真解析**判，不按首字符猜。

    openGauss 的 query_plan 是 **text**（实测 pg_attribute: query_plan | text），而
    datadog_agent.obfuscate_sql_exec_plan 内部是 JSON 扫描器：喂非 JSON 会返回错误，
    经 rtloader 绑定变成 Python 异常。若不先判形，整行会在脱敏阶段抛错被跳过 ——
    表现为流恒空、日志里每行一条 exception。

    判据必须是真解析而不是首字符：同族的 GaussDB 会给参数化语句的文本计划前面加一行
    ``[Parameterized]`` 标签，**首字符是 '['** 却不是 JSON；按首字符猜就会把它喂进
    脱敏器，Go 侧读完 '[' 再读到 'P' 抛 ``invalid character 'P' looking for beginning
    of value``，整行连坐（146.56.217.73 实证，1219/7190 行命中，完成态流 22 小时零行）。

    openGauss 7.0.0-RC1 当前不出这个形态（113.44.110.34:5434 实测 15549 行 0 命中，
    参数化语句记下的计划也只有 ``Datanode Name: sgnode`` 开头），所以这里是加固不是
    回归：两个引擎的计划打印器同源，且 ``enable_opfusion`` 在该实例上是 on。首字符仍
    先筛一道，让绝大多数文本计划在解析器之前短路掉。另一层兜底见 ``_obfuscate``。
    """
    stripped = (plan or "").lstrip()
    if not stripped.startswith(("{", "[")):
        return False
    try:
        json.loads(stripped)
    except Exception:
        return False
    return True


# Runtime column discovery. dbe_perf.statement_history is a view, so pg_attribute over the
# view is what actually constrains the SELECT.
COLUMN_DISCOVERY_QUERY = """
SELECT a.attname
FROM pg_attribute a
JOIN pg_class c ON c.oid = a.attrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'dbe_perf' AND c.relname = 'statement_history'
  AND a.attnum > 0 AND NOT a.attisdropped
"""

# Columns without which a row cannot be interpreted at all: the cursor, the wall-clock span,
# the dedupe key, the SQL text, and the engine's slow verdict. If the engine lacks any of
# these the job must fail loudly rather than ship half-meaningless events.
REQUIRED_COLUMNS = frozenset({"finish_time", "start_time", "debug_query_id", "query", "is_slow_sql"})


def resolve_columns(available: Iterable[str]) -> list:
    """Intersect the desired superset with what this engine actually exposes.

    Order follows the desired list so the generated SQL is stable across runs.
    """
    present = {name for name in available}
    return [name for name in STATEMENT_HISTORY_DESIRED_COLUMNS if name in present]

CURSOR_CACHE_KEY = "statement_history_finish_time_cursor"
EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def _as_utc(value: datetime) -> datetime:
    """Treat a naive engine timestamp as UTC rather than local time."""
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value


def wall_duration_ms(row: dict) -> float:
    """Wall-clock elapsed time of the execution.

    Deliberately not ``db_time``: on a parallel plan db_time accumulates across worker
    threads and exceeds wall clock, which would make @duration incomparable with the
    other engines.
    """
    return (_as_utc(row["finish_time"]) - _as_utc(row["start_time"])).total_seconds() * 1000.0


def max_finish_time(rows: Iterable[dict], cursor: datetime) -> datetime:
    """Advance the cursor to the newest row actually read, never past it.

    Rows dropped by the LIMIT are picked up on the next pass. This is SQL Server's
    conservative semantics rather than ClickHouse's unconditional advance, because
    statement_history has no equivalent of ClickHouse's per-node checkpoint eviction and
    losing a slow query is worse than re-reading one that debug_query_id will dedupe.
    """
    newest = cursor
    for row in rows:
        finish_time = _as_utc(row["finish_time"])
        if finish_time > newest:
            newest = finish_time
    return newest


def completion_row_details(row: dict, *, obfuscated_statement: str, query_signature: str) -> dict:
    """Build one ``query_details`` block from a statement_history row."""
    native = {
        key: row[key]
        for key in STATEMENT_HISTORY_DESIRED_COLUMNS
        if key in row and key not in PROMOTED_COLUMNS and row[key] is not None
    }
    details = {
        "statement": obfuscated_statement,
        "query_signature": query_signature,
        "duration_ms": wall_duration_ms(row),
        "database_name": row.get("db_name"),
        "username": row.get("user_name"),
        "application_name": row.get("application_name"),
        # The engine's own per-execution id: the dedupe key across cursor boundaries and
        # the join key back to a plan event.
        "db_execution_id": row.get("debug_query_id"),
        "start_time": _as_utc(row["start_time"]).isoformat(),
        "finish_time": _as_utc(row["finish_time"]).isoformat(),
    }
    if row.get("client_addr") is not None:
        details["client_addr"] = str(row["client_addr"])
    if row.get("client_port") is not None:
        details["client_port"] = row["client_port"]
    details.update(native)
    return details


def build_completion_payload(
    details_list: list,
    *,
    host: str,
    database_instance: str,
    ddtags: str,
    collection_interval: float,
    opengauss_version: str,
    cloud_metadata: dict,
    service: Any,
    timestamp_ms: float,
) -> dict:
    """Wrap query_details blocks in the dbm-activity completion envelope."""
    return {
        "host": host,
        "database_instance": database_instance,
        "ddagentversion": datadog_agent.get_version(),
        "ddsource": "opengauss",
        "dbm_type": "query_completion",
        "collection_interval": collection_interval,
        "ddtags": ddtags,
        "timestamp": timestamp_ms,
        "opengauss_version": opengauss_version,
        "cloud_metadata": cloud_metadata,
        "service": service,
        "opengauss_query_completions": [{"query_details": details} for details in details_list],
    }


def build_plan_event(
    row: dict,
    *,
    host: str,
    database_instance: str,
    ddtags: str,
    obfuscated_statement: str,
    query_signature: str,
    obfuscated_plan: str | None,
    plan_signature: str | None,
    cloud_metadata: dict,
    service: Any,
    timestamp_ms: float,
) -> dict | None:
    """Build a dbm-samples plan event from the engine-stored plan.

    Returns None when the engine stored no plan for this execution, so callers never emit
    an empty plan envelope.
    """
    if not obfuscated_plan:
        return None
    return {
        "host": host,
        "database_instance": database_instance,
        "ddagentversion": datadog_agent.get_version(),
        "ddsource": "opengauss",
        "dbm_type": "plan",
        "ddtags": ddtags,
        "timestamp": timestamp_ms,
        "cloud_metadata": cloud_metadata,
        "service": service,
        "duration": wall_duration_ms(row) * 1e6,
        "network": {
            "client": {
                "ip": str(row["client_addr"]) if row.get("client_addr") is not None else None,
                "port": row.get("client_port"),
            }
        },
        "db": {
            "instance": row.get("db_name"),
            "plan": {
                "definition": obfuscated_plan,
                "signature": plan_signature,
                # Read from a column, so there is no EXPLAIN failure to report.
                "collection_errors": None,
            },
            "query_signature": query_signature,
            "resource_hash": query_signature,
            "application": row.get("application_name"),
            "user": row.get("user_name"),
            "statement": obfuscated_statement,
        },
        "opengauss": {
            key: row[key]
            for key in STATEMENT_HISTORY_DESIRED_COLUMNS
            if key in row and key not in PROMOTED_COLUMNS and row[key] is not None
        },
    }


class OpenGaussStatementHistory(DBMAsyncJob):
    """Incrementally ship completed slow SQL from dbe_perf.statement_history."""

    def __init__(self, check: OpenGauss, config: InstanceConfig):
        collection_interval = config.statement_history.collection_interval
        super(OpenGaussStatementHistory, self).__init__(
            check,
            rate_limit=1 / collection_interval,
            run_sync=config.statement_history.run_sync,
            enabled=config.statement_history.enabled and config.dbm,
            dbms="opengauss",
            min_collection_interval=config.min_collection_interval,
            expected_db_exceptions=(psycopg.errors.DatabaseError,),
            job_name="statement-history",
        )
        self._check = check
        self._config = config
        self._collection_interval = collection_interval
        self._batch_limit = config.statement_history.batch_limit
        # Boundary dedupe only. The cursor is strict (`finish_time > cursor`), so the sole
        # duplicate source is several rows sharing one finish_time across two passes.
        # A TTL cache expires entries instead of clearing wholesale at a size cap, which
        # would drop dedupe state for every in-flight boundary at once.
        self._seen_execution_ids = TTLCache(
            maxsize=config.statement_history.dedupe_cache_maxsize,
            ttl=max(collection_interval * 10, 60),
        )
        # Identical plan trees repeat across executions; ship each (query, plan) pair once
        # per hour the way the other engines rate-limit their plan streams.
        self._seen_plans = TTLCache(maxsize=config.statement_history.dedupe_cache_maxsize, ttl=3600)
        # Resolved on first collection from the engine's own catalog; see _discover_columns.
        self._columns = None
        # 一次性提醒的闸门：这几类问题按行重复刷日志毫无价值。
        self._warned_text_plan = False
        self._warned_plan_obfuscation = False
        self._warned_prerequisites = False
        obfuscate_options = self._config.obfuscator_options.model_dump()
        obfuscate_options["table_names"] = self._config.obfuscator_options.collect_tables
        obfuscate_options["dollar_quoted_func"] = self._config.obfuscator_options.keep_dollar_quoted_func
        obfuscate_options["return_json_metadata"] = self._config.obfuscator_options.collect_metadata
        obfuscate_options["dbms"] = "postgresql"
        self._obfuscate_options = to_native_string(json.dumps(obfuscate_options))

    def _shutdown(self):
        self._check = None

    # ── cursor ──

    def _load_cursor(self) -> datetime:
        cached = self._check.read_persistent_cache(CURSOR_CACHE_KEY)
        if not cached:
            return EPOCH
        try:
            return _as_utc(datetime.fromisoformat(cached))
        except ValueError:
            self._log.warning("Discarding unparseable statement_history cursor %r", cached)
            return EPOCH

    def _save_cursor(self, finish_time: datetime) -> None:
        self._check.write_persistent_cache(CURSOR_CACHE_KEY, finish_time.isoformat())

    # ── collection ──

    def _discover_columns(self, conn) -> list:
        """Read this engine's real column set once per process and cache it."""
        if self._columns is not None:
            return self._columns

        with conn.cursor() as db_cursor:
            db_cursor.execute(COLUMN_DISCOVERY_QUERY)
            available = [row[0] for row in db_cursor.fetchall()]

        if not available:
            raise psycopg.errors.UndefinedTable(
                "dbe_perf.statement_history exposes no columns — is the view present on this engine?"
            )

        missing_required = REQUIRED_COLUMNS - set(available)
        if missing_required:
            raise psycopg.errors.UndefinedColumn(
                "dbe_perf.statement_history is missing columns this collector cannot work without: "
                + ", ".join(sorted(missing_required))
            )

        columns = resolve_columns(available)
        absent = [c for c in STATEMENT_HISTORY_DESIRED_COLUMNS if c not in set(columns)]
        # Log the shortfall once at info: an operator comparing dashboards across engines
        # needs to know which fields are structurally absent rather than merely empty.
        self._log.info(
            "statement_history: selecting %d of %d desired columns; absent on this engine: %s",
            len(columns),
            len(STATEMENT_HISTORY_DESIRED_COLUMNS),
            ", ".join(absent) if absent else "none",
        )
        self._columns = columns
        return columns

    def _show_int(self, conn, query: str):
        """读一个整型 GUC；读不到返回 None（不让前置检查失败拖垮采集）。"""
        try:
            with conn.cursor() as db_cursor:
                db_cursor.execute(query)
                row = db_cursor.fetchone()
            return int(row[0]) if row else None
        except Exception:
            self._log.debug("statement_history: 读不到 %r，跳过该前置检查", query, exc_info=True)
            return None

    def _check_engine_prerequisites(self, conn) -> None:
        """开采集前查两个前置条件，不满足时 loud 提醒。

        这是「链路全绿但数据没意义」的唯一可见信号，所以两条都给出可直接执行的处置。
        """
        if self._warned_prerequisites:
            return
        self._warned_prerequisites = True

        # ① unique SQL 槽位——最常踩的那个。打满后耗时列恒 0、query 被换成提示串。
        cap = self._show_int(conn, UNIQUE_SQL_COUNT_QUERY)
        used = self._show_int(conn, UNIQUE_SQL_OCCUPANCY_QUERY)
        if cap and used is not None and used >= cap * UNIQUE_SQL_OCCUPANCY_WARN_RATIO:
            self._log.warning(
                "statement_history: unique SQL 槽位 %d/%d 已近满或打满——超出后引擎不再更新时间模型，"
                "分阶段耗时（db_time/cpu_time/parse_time/plan_time/data_io_time/srt*）会恒为 0，"
                "且 query 被回填成 %r 而非真 SQL。处置：调大 instr_unique_sql_count"
                "（默认 100，官方建议 200000）。",
                used,
                cap,
                MISSING_SQL_HINT,
            )

        # ② 慢 SQL 档位。只有 OFF 才是问题——L0 已足够记录 query / query_plan / 分阶段耗时，
        # 且是官方推荐值。5.0.x 及更早例外：那些版本的 query_plan 需要 L1。
        try:
            with conn.cursor() as db_cursor:
                db_cursor.execute(STAT_LEVEL_QUERY)
                row = db_cursor.fetchone()
        except Exception:
            self._log.debug("statement_history: 读不到 track_stmt_stat_level，跳过档位检查", exc_info=True)
            return
        if not row:
            return
        setting = str(row[0])
        level = slow_stat_level(setting)
        if level in INSUFFICIENT_SLOW_STAT_LEVELS:
            self._log.warning(
                "statement_history: track_stmt_stat_level=%r，慢 SQL 档位为 %s——该档位下引擎"
                "一行都不写。处置：把第二段设为 L0（官方推荐 'L0,L0'）。",
                setting,
                level,
            )
        else:
            self._log.debug(
                "statement_history: track_stmt_stat_level=%r（慢 SQL 档位 %s，足够）", setting, level
            )

    def _fetch_rows(self, cursor: datetime):
        with self._check.db_pool.get_connection(self._config.dbname) as conn:
            columns = self._discover_columns(conn)
            self._check_engine_prerequisites(conn)
            query = STATEMENT_HISTORY_QUERY.format(columns=", ".join(columns))
            with conn.cursor(row_factory=dict_row) as db_cursor:
                db_cursor.execute(query, (cursor, self._batch_limit))
                return db_cursor.fetchall()

    def _dbtags(self, db_name) -> list:
        tags = [t for t in self._tags if not t.startswith("db:")]
        if db_name:
            tags.append("db:{}".format(db_name))
        return tags

    def _obfuscate(self, row: dict):
        statement = obfuscate_sql_with_metadata(row["query"], self._obfuscate_options)
        obfuscated_query = statement["query"]
        query_signature = compute_sql_signature(obfuscated_query)
        obfuscated_plan, plan_signature = None, None
        query_plan = row.get("query_plan")
        if query_plan and looks_like_json_plan(query_plan):
            try:
                obfuscated_plan = datadog_agent.obfuscate_sql_exec_plan(query_plan)
                normalized_plan = datadog_agent.obfuscate_sql_exec_plan(query_plan, normalize=True)
                plan_signature = compute_exec_plan_signature(normalized_plan)
            except Exception:
                # 计划字段降级为空，其余列照常上报。判形是启发式，早晚会被没见过的
                # query_plan 形态再骗一次；真正兜住的是这一层——计划脱敏失败只丢计划，
                # 不能把 statement / query_signature / 各阶段耗时 / 锁计数一起连坐。
                obfuscated_plan, plan_signature = None, None
                if not self._warned_plan_obfuscation:
                    self._warned_plan_obfuscation = True
                    self._log.exception(
                        "statement_history: query_plan 脱敏失败，本行只丢计划字段、"
                        "其余列照常上报（同类失败后续不再重复记录）"
                    )
        elif query_plan and not self._warned_text_plan:
            # 文本计划无法经 JSON 脱敏器处理，而原文可能带 Filter 里的字面量，直接上报会漏敏。
            # 故不产出 plan 事件，只提醒一次；completion 事件本身不受影响。
            self._warned_text_plan = True
            self._log.warning(
                "statement_history: query_plan 是文本格式而非 JSON，跳过 plan 事件上报"
                "（completion 事件不受影响）。文本计划无法经 JSON 脱敏器处理，"
                "原样上报会带出 Filter 里的字面量。"
            )
        return obfuscated_query, query_signature, obfuscated_plan, plan_signature, statement.get("metadata") or {}

    @tracked_method(agent_check_getter=agent_check_getter)
    def run_job(self):
        cursor = self._load_cursor()
        rows = self._fetch_rows(cursor)
        if not rows:
            self._log.debug("No new completed slow SQL past cursor %s", cursor)
            return

        timestamp_ms = time.time() * 1000
        details_list = []
        plan_events = []
        skipped_no_statement = 0
        for row in rows:
            # 两种没有可用 SQL 文本的行都要跳过：空串（引擎没写），以及 unique SQL 槽位打满时
            # 内核回填的提示串。后者更隐蔽——它非空，不跳的话所有行会用同一句提示串算出
            # 同一个签名，把整条流污染成"一个超慢查询被执行了几万次"。
            statement_text = (row.get("query") or "").strip()
            if not statement_text or is_missing_sql_hint(statement_text):
                skipped_no_statement += 1
                continue
            execution_id = row.get("debug_query_id")
            if execution_id is not None and execution_id in self._seen_execution_ids:
                continue
            if execution_id is not None:
                self._seen_execution_ids[execution_id] = True
            try:
                statement, query_signature, plan, plan_signature, metadata = self._obfuscate(row)
            except Exception:
                self._log.exception("Failed to obfuscate statement_history row, skipping it")
                continue

            details = completion_row_details(
                row, obfuscated_statement=statement, query_signature=query_signature
            )
            details["metadata"] = {
                "tables": metadata.get("tables"),
                "commands": metadata.get("commands"),
                "comments": metadata.get("comments"),
            }
            details_list.append(details)

            plan_key = (query_signature, plan_signature)
            if plan_signature and plan_key not in self._seen_plans:
                self._seen_plans[plan_key] = True
                event = build_plan_event(
                    row,
                    host=self._check.reported_hostname,
                    database_instance=self._check.database_identifier,
                    ddtags=",".join(self._dbtags(row.get("db_name"))),
                    obfuscated_statement=statement,
                    query_signature=query_signature,
                    obfuscated_plan=plan,
                    plan_signature=plan_signature,
                    cloud_metadata=self._check.cloud_metadata,
                    service=self._config.service,
                    timestamp_ms=timestamp_ms,
                )
                if event is not None:
                    event["db"]["metadata"] = details["metadata"]
                    plan_events.append(event)

        # Plans first: a completion event referencing a plan_signature should not land
        # before the plan it points at.
        for event in plan_events:
            self._check.database_monitoring_query_sample(
                json.dumps(event, default=default_json_event_encoding)
            )

        if details_list:
            payload = build_completion_payload(
                details_list,
                host=self._check.reported_hostname,
                database_instance=self._check.database_identifier,
                # A list, matching what ClickHouse and SQL Server put on the activity
                # intake; the per-row plan events keep the comma-joined samples form.
                ddtags=self._dbtags(None),
                collection_interval=self._collection_interval,
                opengauss_version=self._check.gaussdb_version or self._check.raw_version or "",
                cloud_metadata=self._check.cloud_metadata,
                service=self._config.service,
                timestamp_ms=timestamp_ms,
            )
            self._check.database_monitoring_query_activity(
                json.dumps(payload, default=default_json_event_encoding)
            )

        self._save_cursor(max_finish_time(rows, cursor))

        self._check.count(
            "dd.opengauss.statement_history.completions_submitted.count",
            len(details_list),
            tags=self._tags + self._check._get_debug_tags(),
            hostname=self._check.reported_hostname,
            raw=True,
        )
        if skipped_no_statement:
            self._log.warning(
                "statement_history: 本轮 %d/%d 行没有可用 SQL 文本被跳过——最常见原因是 "
                "instr_unique_sql_count 槽位打满（引擎回填 %r 代替真 SQL）",
                skipped_no_statement,
                len(rows),
                MISSING_SQL_HINT,
            )
        self._check.count(
            "dd.opengauss.statement_history.rows_missing_statement.count",
            skipped_no_statement,
            tags=self._tags + self._check._get_debug_tags(),
            hostname=self._check.reported_hostname,
            raw=True,
        )
        self._check.count(
            "dd.opengauss.statement_history.plans_submitted.count",
            len(plan_events),
            tags=self._tags + self._check._get_debug_tags(),
            hostname=self._check.reported_hostname,
            raw=True,
        )
