# (C) Datadog, Inc. 2026-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
from __future__ import annotations

import re
import time

import psycopg
from psycopg.rows import dict_row

try:
    import datadog_agent
except ImportError:
    from datadog_checks.base.stubs import datadog_agent

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datadog_checks.gaussdb import GaussDb

from datadog_checks.base.utils.db.health import HealthStatus
from datadog_checks.base.utils.db.utils import default_json_event_encoding
from datadog_checks.base.utils.serialization import json
from datadog_checks.base.utils.tracking import tracked_method

from .diagnose import _safe_identifier
from .filters import regex_exclude_clauses, regex_include_clause
from .health import PostgresHealthEvent
from .util import payload_pg_version


# Upstream ships the helper in the `datadog` schema. dbdog deployments rename the monitoring
# account and its schema to `dbdog`, so the call target is configurable the same way
# `query_samples.explain_function` already is -- the default below keeps upstream behaviour.
DEFAULT_COLUMN_STATISTICS_FUNCTION = "datadog.column_statistics()"


def agent_check_getter(self):
    return self._check


COLUMN_STATISTICS_QUERY = """\
WITH tables AS (
    SELECT n.nspname AS schemaname, c.relname AS tablename
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname NOT IN ('pg_catalog', 'information_schema')
      AND c.relkind = 'r'
      {filters}
    ORDER BY n.nspname, c.relname
    LIMIT %s
),
column_data AS (
    SELECT
        t.schemaname,
        t.tablename,
        json_build_object(
            'name', s.attname,
            'avg_width', s.avg_width,
            'n_distinct', s.n_distinct,
            'null_frac', s.null_frac,
            'inherited', s.inherited,
            'correlation', s.correlation,
            'most_common_freqs', s.most_common_freqs
        ) AS col,
        EXTRACT(EPOCH FROM (NOW() - st.last_analyze))::bigint AS last_analyze_age,
        EXTRACT(EPOCH FROM (NOW() - st.last_autoanalyze))::bigint AS last_autoanalyze_age,
        EXTRACT(EPOCH FROM (NOW() - st.last_vacuum))::bigint AS last_vacuum_age,
        EXTRACT(EPOCH FROM (NOW() - st.last_autovacuum))::bigint AS last_autovacuum_age,
        EXTRACT(EPOCH FROM (NOW() - GREATEST(st.last_analyze, st.last_autoanalyze)))::bigint AS stats_age
    FROM {function} s
    JOIN tables t ON t.schemaname = s.schemaname AND t.tablename = s.tablename
    JOIN pg_stat_all_tables st ON st.schemaname = t.schemaname AND st.relname = t.tablename
)
SELECT
    schemaname,
    tablename,
    json_agg(col ORDER BY col->>'name') AS columns,
    (array_agg(last_analyze_age))[1] AS last_analyze_age,
    (array_agg(last_autoanalyze_age))[1] AS last_autoanalyze_age,
    (array_agg(last_vacuum_age))[1] AS last_vacuum_age,
    (array_agg(last_autovacuum_age))[1] AS last_autovacuum_age,
    (array_agg(stats_age))[1] AS stats_age
FROM column_data
GROUP BY schemaname, tablename
ORDER BY schemaname, tablename
"""


PAYLOAD_MAX_COLUMNS = 5_000
MAX_QUERY_DURATION_SECONDS = 60


class PostgresColumnStatisticsCollectorConfig:
    def __init__(self):
        self.collection_interval = 3600
        self.max_tables = 500
        self.function_name = DEFAULT_COLUMN_STATISTICS_FUNCTION
        self.include_databases: list[str] = []
        self.exclude_databases: list[str] = []
        self.include_schemas: list[str] = []
        self.exclude_schemas: list[str] = []
        self.include_tables: list[str] = []
        self.exclude_tables: list[str] = []


class PostgresColumnStatisticsCollector:
    """Collects column statistics from pg_stats via the configured column-statistics function."""

    def __init__(self, check: GaussDb, cancel_event):
        self._check = check
        self._log = check.log
        self._cancel_event = cancel_event
        self._config = PostgresColumnStatisticsCollectorConfig()
        self._config.collection_interval = check._config.collect_column_statistics.collection_interval
        self._config.max_tables = check._config.collect_column_statistics.max_tables
        self._config.include_databases = list(check._config.collect_column_statistics.include_databases or [])
        self._config.exclude_databases = list(check._config.collect_column_statistics.exclude_databases or [])
        self._config.include_schemas = list(check._config.collect_column_statistics.include_schemas or [])
        self._config.exclude_schemas = list(check._config.collect_column_statistics.exclude_schemas or [])
        self._config.include_tables = list(check._config.collect_column_statistics.include_tables or [])
        self._config.exclude_tables = list(check._config.collect_column_statistics.exclude_tables or [])
        self._config.function_name = (
            check._config.collect_column_statistics.function_name or DEFAULT_COLUMN_STATISTICS_FUNCTION
        )
        self._function_not_found_dbs: set[str] = set()
        self._insufficient_privilege_dbs: set[str] = set()
        self._reset()

    def _reset(self):
        self._collection_started_at = None
        self._total_tables_count = 0
        self._total_columns_count = 0
        self._payloads_count = 0
        self._queued_tables = []
        self._queued_columns_count = 0

    @property
    def _base_event(self):
        return {
            "host": self._check.reported_hostname,
            "database_instance": self._check.database_identifier,
            "ddagentversion": datadog_agent.get_version(),
            "dbms": "gaussdb",
            "dbms_version": self._check.dbms_version,
            "cloud_metadata": self._check.cloud_metadata,
            "dbm_type": "column_statistics",
            "collection_interval": self._config.collection_interval,
        }

    def _build_filters(self) -> tuple[str, list[str]]:
        query = ""
        params: list[str] = []

        query += regex_exclude_clauses("n.nspname", self._config.exclude_schemas)
        params.extend(self._config.exclude_schemas)

        query += regex_include_clause("n.nspname", self._config.include_schemas)
        params.extend(self._config.include_schemas)

        query += regex_exclude_clauses("c.relname", self._config.exclude_tables)
        params.extend(self._config.exclude_tables)

        query += regex_include_clause("c.relname", self._config.include_tables)
        params.extend(self._config.include_tables)

        return query, params

    def _get_databases(self):
        if self._check.autodiscovery:
            databases = list(self._check.autodiscovery.get_items() or [])
        else:
            databases = [self._check._config.dbname]
        if self._config.exclude_databases:
            databases = [db for db in databases if not any(re.search(p, db) for p in self._config.exclude_databases)]
        if self._config.include_databases:
            databases = [db for db in databases if any(re.search(p, db) for p in self._config.include_databases)]
        return databases

    @tracked_method(agent_check_getter=agent_check_getter)
    def collect_column_statistics(self, tags_no_db: list[str]) -> bool:
        """Collect column statistics across all discovered databases."""
        status = "success"
        try:
            self._collection_started_at = time.time() * 1000

            if self._cancel_event.is_set():
                self._log.debug("Column stats collection cancelled")
                return True

            databases = self._get_databases()
            self._log.debug("Collecting column stats for %d databases", len(databases))

            for db_name in databases:
                if self._cancel_event.is_set():
                    self._log.debug("Column stats collection cancelled")
                    break
                self._collect_for_database(db_name, tags_no_db)

            self._log.debug(
                "Submitted column stats: %d tables, %d columns, %d payloads across %d databases",
                self._total_tables_count,
                self._total_columns_count,
                self._payloads_count,
                len(databases),
            )
            return True
        except Exception as e:
            status = "error"
            self._log.error("Error collecting column stats: %s", e)
            raise
        finally:
            elapsed = (time.time() * 1000) - self._collection_started_at if self._collection_started_at else 0
            tags = self._check.tags + ["status:" + status]
            self._check.histogram(
                "dd.gaussdb.column_statistics.time",
                elapsed,
                tags=tags,
                hostname=self._check.reported_hostname,
                raw=True,
            )
            self._check.gauge(
                "dd.gaussdb.column_statistics.tables_count",
                self._total_tables_count,
                tags=tags,
                hostname=self._check.reported_hostname,
                raw=True,
            )
            self._check.gauge(
                "dd.gaussdb.column_statistics.columns_count",
                self._total_columns_count,
                tags=tags,
                hostname=self._check.reported_hostname,
                raw=True,
            )
            self._check.gauge(
                "dd.gaussdb.column_statistics.payloads_count",
                self._payloads_count,
                tags=tags,
                hostname=self._check.reported_hostname,
                raw=True,
            )
            self._reset()

    @tracked_method(agent_check_getter=agent_check_getter)
    def _collect_for_database(self, db_name: str, tags_no_db: list[str]):
        try:
            with self._check.db_pool.get_connection(db_name) as conn:
                with conn.cursor(row_factory=dict_row) as cursor:
                    filters_sql, filter_params = self._build_filters()
                    query = COLUMN_STATISTICS_QUERY.format(
                        filters=filters_sql, function=_safe_identifier(self._config.function_name)
                    )
                    filter_params.append(self._config.max_tables)
                    cursor.execute("SET statement_timeout = %s", (MAX_QUERY_DURATION_SECONDS * 1000,))
                    try:
                        cursor.execute(query, filter_params)

                        self._handle_recovery(db_name)

                        row = cursor.fetchone()
                        while row:
                            table_data = self._map_row(db_name, row)
                            table_data['version'] = 1
                            num_columns = len(table_data['columns'])
                            self._queued_tables.append(table_data)
                            self._queued_columns_count += num_columns
                            self._total_tables_count += 1
                            self._total_columns_count += num_columns
                            row = cursor.fetchone()
                            if self._queued_columns_count >= PAYLOAD_MAX_COLUMNS:
                                self._flush(tags_no_db)
                    finally:
                        try:
                            cursor.execute("RESET statement_timeout")
                        except Exception:
                            pass

            # Flush at database boundary
            if self._queued_tables:
                self._flush(tags_no_db)

        except psycopg.errors.DatabaseError as e:
            if isinstance(e, psycopg.errors.UndefinedFunction):
                if db_name not in self._function_not_found_dbs:
                    self._function_not_found_dbs.add(db_name)
                    self._log.warning(
                        "%s function not found in database '%s'. "
                        "Please create the function as described in the documentation: "
                        "https://docs.datadoghq.com/database_monitoring/setup_postgres/",
                        self._config.function_name,
                        db_name,
                    )
                    self._check.health.submit_health_event(
                        name=PostgresHealthEvent.COLUMN_STATISTICS_FUNCTION_NOT_FOUND,
                        status=HealthStatus.WARNING,
                    )
            elif isinstance(e, psycopg.errors.InsufficientPrivilege):
                if db_name not in self._insufficient_privilege_dbs:
                    self._insufficient_privilege_dbs.add(db_name)
                    self._log.warning(
                        "Insufficient privileges to execute %s in database '%s'. "
                        "Please check the function permissions.",
                        self._config.function_name,
                        db_name,
                    )
                    self._check.health.submit_health_event(
                        name=PostgresHealthEvent.COLUMN_STATISTICS_INSUFFICIENT_PRIVILEGE,
                        status=HealthStatus.WARNING,
                    )
            else:
                self._log.exception("Error collecting column stats for database '%s'", db_name)
        except Exception:
            self._log.exception("Error collecting column stats for database '%s'", db_name)

    def _handle_recovery(self, db_name: str):
        if db_name in self._function_not_found_dbs:
            self._function_not_found_dbs.discard(db_name)
            self._log.info(
                "%s function is now available in database '%s'", self._config.function_name, db_name
            )
            if not self._function_not_found_dbs:
                self._check.health.submit_health_event(
                    name=PostgresHealthEvent.COLUMN_STATISTICS_FUNCTION_NOT_FOUND,
                    status=HealthStatus.OK,
                )
        if db_name in self._insufficient_privilege_dbs:
            self._insufficient_privilege_dbs.discard(db_name)
            self._log.info("%s privileges restored in database '%s'", self._config.function_name, db_name)
            if not self._insufficient_privilege_dbs:
                self._check.health.submit_health_event(
                    name=PostgresHealthEvent.COLUMN_STATISTICS_INSUFFICIENT_PRIVILEGE,
                    status=HealthStatus.OK,
                )

    def _map_row(self, db_name: str, row):
        return {
            'db': db_name,
            'schema': row['schemaname'],
            'table': row['tablename'],
            'last_analyze_age': row.get('last_analyze_age'),
            'last_autoanalyze_age': row.get('last_autoanalyze_age'),
            'last_vacuum_age': row.get('last_vacuum_age'),
            'last_autovacuum_age': row.get('last_autovacuum_age'),
            'stats_age': row.get('stats_age'),
            'columns': row.get('columns') or [],
        }

    def _flush(self, tags_no_db: list[str]):
        if self._queued_tables:
            event = self._base_event
            event["tags"] = tags_no_db
            event["timestamp"] = time.time() * 1000
            event["column_statistics"] = self._queued_tables
            self._payloads_count += 1
            self._check.database_monitoring_column_statistics(json.dumps(event, default=default_json_event_encoding))
            self._queued_tables = []
            self._queued_columns_count = 0
