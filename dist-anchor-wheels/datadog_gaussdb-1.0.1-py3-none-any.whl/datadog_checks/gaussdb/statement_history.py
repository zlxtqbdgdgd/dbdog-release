# (C) Datadog, Inc. 2026-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
"""Collect completed slow SQL from ``dbe_perf.statement_history`` as DBM events.

This is the DBM-native path, modelled on the three engines that already ship a
completed-query stream:

* ClickHouse ``query_completions.py`` — historical table + persistent cursor, batched
  ``query_completion`` payload on the dbm-activity track.
* SQL Server ``xe_collection`` — engine-prefixed batch key, cursor advanced only to the
  last row actually read.
* Oracle ``statements.go`` — execution plans read from an engine-stored column rather
  than produced by running EXPLAIN.

Two differences from ClickHouse are deliberate and engine-driven:

* No per-signature sample rate limiting. GaussDB decides slowness itself via
  ``is_slow_sql`` / ``slow_sql_threshold``, so rows arriving here are already filtered;
  re-sampling would drop consecutive degradations of the same query. ClickHouse has to
  sample because ``system.query_log`` holds every execution, slow or not.
* No EXPLAIN. ``query_plan`` is the plan the engine actually used, so re-planning would
  both cost the database and risk reporting a plan that never ran.

GaussDB is **not** openGauss with a different name. Read-only comparison on 2026-08-10
(GaussDB Kernel 507.0.0 vs openGauss 7.0.0-RC1): 53 columns in common, 19 exclusive to
GaussDB, 18 exclusive to openGauss. Every engine-facing constant in this module describes
GaussDB and only GaussDB; the real column set is still discovered at runtime because
GaussDB drifts against itself across versions too.
"""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Iterable

import psycopg
from cachetools import TTLCache
from psycopg.rows import dict_row

from datadog_checks.base.utils.common import to_native_string
from datadog_checks.base.utils.db.sql import compute_exec_plan_signature, compute_sql_signature
from datadog_checks.base.utils.db.utils import (
    DBMAsyncJob,
    default_json_event_encoding,
    obfuscate_sql_with_metadata,
)
from datadog_checks.base.utils.serialization import json
from datadog_checks.base.utils.tracking import tracked_method
from datadog_checks.gaussdb.config_models import InstanceConfig
from datadog_checks.gaussdb.statement_samples import agent_check_getter

try:
    import datadog_agent
except ImportError:
    from datadog_checks.base.stubs import datadog_agent

if TYPE_CHECKING:
    from datadog_checks.gaussdb import GaussDb

# Columns present in dbe_perf.statement_history but deliberately not selected.
#
# Two groups, both measured on 507.0.0 (2026-08-10):
#
# * Unbounded text / bytea blobs: the four ``net_*_info`` counters and ``details``
#   (the L2 lock-event stream, ``bytea``, capped by ``track_stmt_details_size`` — 4096 here).
# * Driver-side probes: ``driver_start_time`` / ``driver_wait_response`` /
#   ``driver_finish_time`` were NULL on all 4887 rows and ``driver_info`` was the constant
#   ``{"unrelated": "no ticket from frontend"}`` — they are populated only when a JDBC
#   driver supplies a request ticket. ``kernel_info`` is a schema-less JSON message
#   timeline (``recv Q`` / ``send T`` / ``send D`` / ``send C`` / ``send Z``) that restates
#   start_time and finish_time.
STATEMENT_HISTORY_SKIP_COLUMNS = frozenset(
    {
        "net_send_info",
        "net_recv_info",
        "net_stream_send_info",
        "net_stream_recv_info",
        "details",
        "driver_start_time",
        "driver_wait_response",
        "driver_finish_time",
        "driver_info",
        "kernel_info",
    }
)

# The **superset** of GaussDB columns worth shipping — not one instance's truth.
#
# Why no fixed list works: the shape of dbe_perf.statement_history differs per engine and
# per version. Read-only reads:
#   GaussDB Kernel 507.0.0 (146.56.217.73:5432, 2026-08-10) — 72 columns
#   openGauss 7.0.0-RC1    (ecs-8ea7 :5434,     2026-08-09) — 71 columns
# and only 53 of those are shared. An earlier GaussDB build recorded 14 exclusive columns
# where 507.0.0 has 19: driver_{start_time,wait_response,finish_time,info} and kernel_info
# arrived later. Same "72 columns", different columns.
#
# Hardcoding any one of those lists makes the SELECT fail with "column does not exist" —
# and that error is classified as an expected DB exception, so the job logs a warning,
# counts it, and keeps looping: the stream stays empty without ever failing loudly.
# The real column set is therefore discovered at runtime and intersected with this superset.
#
# Order follows attnum on 507.0.0 so the generated SQL reads like the catalog.
STATEMENT_HISTORY_DESIRED_COLUMNS = [
    "db_name",
    "schema_name",
    "origin_node",
    "user_name",
    "application_name",
    "client_addr",
    "client_port",
    "unique_query_id",
    "debug_query_id",
    "query",
    "start_time",
    "finish_time",
    "slow_sql_threshold",
    "transaction_id",
    "thread_id",
    "session_id",
    "n_soft_parse",
    "n_hard_parse",
    "query_plan",
    "n_returned_rows",
    "n_tuples_fetched",
    "n_tuples_returned",
    "n_tuples_inserted",
    "n_tuples_updated",
    "n_tuples_deleted",
    "n_blocks_fetched",
    "n_blocks_hit",
    "db_time",
    "cpu_time",
    "execution_time",
    "parse_time",
    "plan_time",
    "rewrite_time",
    "pl_execution_time",
    "pl_compilation_time",
    "data_io_time",
    "lock_count",
    "lock_time",
    "lock_wait_count",
    "lock_wait_time",
    "lock_max_count",
    "lwlock_count",
    "lwlock_wait_count",
    "lwlock_time",
    "lwlock_wait_time",
    "is_slow_sql",
    "trace_id",
    "advise",
    # GaussDB-only from here down. Its answer to "what happened on this execution" is the
    # hash/status/adaptive-plan family, not openGauss's srt* response-time breakdown.
    "parent_unique_sql_id",
    "finish_status",
    "used_memory",
    "lock_max_local_count",
    "lock_max_fastpath_count",
    "lock_max_global_count",
    "sql_hash",
    "plan_hash",
    "plan_hash_prev",
    "adaptive_join_states",
    "aplan_count",
    "aplan_parse_time",
    "aplan_execution_time",
    "relids",
]

# 引擎归属备忘，供日志与 skill 用；不参与 SQL 构造（真实可用列一律运行期取交集）。
# 507.0.0 实测：GaussDB 有这 19 列而 openGauss 一个都没有。
GAUSSDB_ONLY_COLUMNS = frozenset(
    {
        "parent_unique_sql_id",
        "finish_status",
        "used_memory",
        "lock_max_local_count",
        "lock_max_fastpath_count",
        "lock_max_global_count",
        "sql_hash",
        "plan_hash",
        "plan_hash_prev",
        "adaptive_join_states",
        "aplan_count",
        "aplan_parse_time",
        "aplan_execution_time",
        "relids",
        "driver_start_time",
        "driver_wait_response",
        "driver_finish_time",
        "driver_info",
        "kernel_info",
    }
)

# openGauss 有而 GaussDB 没有的 18 列。列在这里**只为把它们挡在外面**：
# 一旦混进 DESIRED，SELECT 会在 GaussDB 上报 column does not exist，
# 而那类错误被归为预期异常 → 只留一条 warning → 流恒空且不报错。
OPENGAUSS_ONLY_COLUMNS = frozenset(
    {
        "parent_query_id",
        "net_send_time",
        "net_trans_time",
        "rtt_unknown",
    }
    | {"srt1_q", "srt2_simple_query", "srt3_analyze_rewrite", "srt4_plan_query", "srt5_light_query"}
    | {"srt6_p", "srt7_b", "srt8_e", "srt9_d", "srt10_s", "srt11_c", "srt12_u"}
    | {"srt13_before_query", "srt14_after_query"}
)

# Columns promoted onto the top level of query_details, so they are not duplicated in the
# engine-native block. query_plan is promoted and then dropped: the raw plan text can carry
# literals from Filter/Index Cond conditions and must never ride the completion envelope.
PROMOTED_COLUMNS = frozenset(
    {
        "db_name",
        "user_name",
        "application_name",
        "client_addr",
        "client_port",
        "query",
        "query_plan",
        "start_time",
        "finish_time",
        "debug_query_id",
    }
)

STATEMENT_HISTORY_QUERY = (
    "SELECT {columns} FROM dbe_perf.statement_history "
    "WHERE is_slow_sql = true AND finish_time > %s "
    "ORDER BY finish_time ASC LIMIT %s"
)

# ── 引擎侧前置条件 ──
#
# 这条流有两个前置条件，且**最容易踩的那个不是档位**。
#
# 1) instr_unique_sql_count（默认 100，官方建议 200000）。unique SQL 哈希表打满后内核不再
#    为新语句登记，query 被回填成一句提示串（MISSING_SQL_HINT）而不是真 SQL。
#    2026-08-10 在 507.0.0 实测：dbe_perf.statement 正好 100 条（打满），statement_history
#    4887 行的 query **全部**是那句提示串——整条流一行可用签名都拿不到。
#    与 openGauss 的差别：openGauss 打满时分阶段耗时同时归零，而 507.0.0 上 4887 行的
#    db_time 仍全部非 0。所以在 GaussDB 上打满的症状是「SQL 文本没了」，不是「耗时没了」。
#
# 2) track_stmt_stat_level 的慢 SQL 档位。**L0 就够**——507.0.0 实测 'OFF,L0' 之下
#    statement_history 有 4887 行、query_plan 100% 非空、分阶段耗时全部有值。
#    所以这里只在档位为 OFF（连行都不写）时警告，不为 L0 报警。
STAT_LEVEL_QUERY = "SHOW track_stmt_stat_level"
UNIQUE_SQL_COUNT_QUERY = "SHOW instr_unique_sql_count"
UNIQUE_SQL_OCCUPANCY_QUERY = "SELECT count(*) FROM dbe_perf.statement"

# 慢 SQL 档位为 OFF 时 statement_history 一行都不会写。
INSUFFICIENT_SLOW_STAT_LEVELS = frozenset({"OFF"})

# unique SQL 槽位打满时内核回填进 query 的提示串。实测原文：
# '/* missing SQL statement, GUC instr_unique_sql_count is too small. */'
# 这不是 SQL，拿它算签名会让所有行塌成同一个签名。
MISSING_SQL_HINT = "missing SQL statement"

# 非 DML/DQL 语句的 query_plan 是一句告示，不是计划（507.0.0 实测原文）。
# 当成计划会让「文本计划」告警对着一句告示喊。
PLAN_NOT_RECORDED_NOTICE = "Do not record plans for non-DML/DQL statements."

# 占用率达到这个比例就提醒：打满前就该扩，满了之后已经在丢数据。
UNIQUE_SQL_OCCUPANCY_WARN_RATIO = 0.9


def slow_stat_level(setting: str) -> str:
    """从 '<full>,<slow>' 取慢 SQL 档位；形态不认识时返回原串交由调用方判断。"""
    parts = [p.strip().upper() for p in (setting or "").split(",")]
    return parts[1] if len(parts) == 2 else (setting or "").strip().upper()


def is_missing_sql_hint(query: str) -> bool:
    """query 是否内核在 unique SQL 槽位打满时回填的提示串，而不是真 SQL。"""
    return MISSING_SQL_HINT in (query or "")


def has_recorded_plan(plan: str) -> bool:
    """query_plan 里是否真有一份计划，而不是空值或引擎的「未记录」告示。"""
    stripped = (plan or "").strip()
    return bool(stripped) and stripped != PLAN_NOT_RECORDED_NOTICE


def looks_like_json_plan(plan: str) -> bool:
    """query_plan 是否 JSON —— 按**能不能真解析**判，不按首字符猜。

    GaussDB 的 query_plan 是 **text**（实测 pg_attribute: query_plan | text），
    507.0.0 上 0 行是 JSON。而 datadog_agent.obfuscate_sql_exec_plan 内部是 JSON
    扫描器：喂非 JSON 会返回错误，经 rtloader 绑定变成 Python 异常。

    文本计划有两种开头，按首字符猜只挡得住第一种：

    * ``Datanode Name: cn_0`` 开头 —— 首字符 'D'，猜得对；
    * ``[Parameterized]`` 标签行开头 —— **首字符是 '['**，会被猜成 JSON 数组。
      2026-08-11 靶机（146.56.217.73:5432）实测 1219/7190 行是这一形态；喂进脱敏器后
      Go 侧读完 '[' 再读到 'P' 抛 ``invalid character 'P' looking for beginning of
      value``，把整行带走，完成态流 22 小时零行、日志同一堆栈 276 次仍在涨。

    所以这里先做一次真解析：解析得动才算 JSON。首字符仍先筛一道，是为了让绝大多数
    文本计划在解析器之前就短路掉。判形之外还有一层兜底 —— 见 ``_obfuscate``：脱敏
    真抛错时只丢计划字段，不丢整行。
    """
    stripped = (plan or "").lstrip()
    if not stripped.startswith(("{", "[")):
        return False
    try:
        json.loads(stripped)
    except Exception:
        return False
    return True


# Runtime column discovery. dbe_perf.statement_history is a view, so pg_attribute over the
# view is what actually constrains the SELECT.
COLUMN_DISCOVERY_QUERY = """
SELECT a.attname
FROM pg_attribute a
JOIN pg_class c ON c.oid = a.attrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'dbe_perf' AND c.relname = 'statement_history'
  AND a.attnum > 0 AND NOT a.attisdropped
"""

# Columns without which a row cannot be interpreted at all: the cursor, the wall-clock span,
# the dedupe key, the SQL text, and the engine's slow verdict. If the engine lacks any of
# these the job must fail loudly rather than ship half-meaningless events.
REQUIRED_COLUMNS = frozenset({"finish_time", "start_time", "debug_query_id", "query", "is_slow_sql"})


def resolve_columns(available: Iterable[str]) -> list:
    """Intersect the desired superset with what this engine actually exposes.

    Order follows the desired list so the generated SQL is stable across runs.
    """
    present = set(available)
    return [name for name in STATEMENT_HISTORY_DESIRED_COLUMNS if name in present]


CURSOR_CACHE_KEY = "statement_history_finish_time_cursor"
EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def _as_utc(value: datetime) -> datetime:
    """Treat a naive engine timestamp as UTC rather than local time."""
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value


def wall_duration_ms(row: dict) -> float:
    """Wall-clock elapsed time of the execution.

    Deliberately not ``db_time``: on a parallel plan db_time accumulates across worker
    threads and exceeds wall clock, which would make @duration incomparable with the
    other engines.
    """
    return (_as_utc(row["finish_time"]) - _as_utc(row["start_time"])).total_seconds() * 1000.0


def max_finish_time(rows: Iterable[dict], cursor: datetime) -> datetime:
    """Advance the cursor to the newest row actually read, never past it.

    Rows dropped by the LIMIT are picked up on the next pass. This is SQL Server's
    conservative semantics rather than ClickHouse's unconditional advance, because
    statement_history has no equivalent of ClickHouse's per-node checkpoint eviction and
    losing a slow query is worse than re-reading one that debug_query_id will dedupe.
    """
    newest = cursor
    for row in rows:
        finish_time = _as_utc(row["finish_time"])
        if finish_time > newest:
            newest = finish_time
    return newest


def native_columns(row: dict) -> dict:
    """引擎原生列（去掉已提升到顶层的那批、去掉 NULL）。

    GaussDB 默认 A（Oracle）兼容模式下空串即 NULL，所以 advise / trace_id / relids /
    adaptive_join_states 这类列在真机上回来是 None，会在这里被整列丢掉——这是对的，
    空值上线只会把每条事件撑大。
    """
    return {
        key: row[key]
        for key in STATEMENT_HISTORY_DESIRED_COLUMNS
        if key in row and key not in PROMOTED_COLUMNS and row[key] is not None
    }


def completion_row_details(row: dict, *, obfuscated_statement: str, query_signature: str) -> dict:
    """Build one ``query_details`` block from a statement_history row."""
    details = {
        "statement": obfuscated_statement,
        "query_signature": query_signature,
        "duration_ms": wall_duration_ms(row),
        "database_name": row.get("db_name"),
        "username": row.get("user_name"),
        "application_name": row.get("application_name"),
        # The engine's own per-execution id: the dedupe key across cursor boundaries and
        # the join key back to a plan event.
        "db_execution_id": row.get("debug_query_id"),
        "start_time": _as_utc(row["start_time"]).isoformat(),
        "finish_time": _as_utc(row["finish_time"]).isoformat(),
    }
    if row.get("client_addr") is not None:
        details["client_addr"] = str(row["client_addr"])
    if row.get("client_port") is not None:
        details["client_port"] = row["client_port"]
    details.update(native_columns(row))
    return details


def build_completion_payload(
    details_list: list,
    *,
    host: str,
    database_instance: str,
    ddtags: str,
    collection_interval: float,
    gaussdb_version: str,
    cloud_metadata: dict,
    service: Any,
    timestamp_ms: float,
) -> dict:
    """Wrap query_details blocks in the dbm-activity completion envelope."""
    return {
        "host": host,
        "database_instance": database_instance,
        "ddagentversion": datadog_agent.get_version(),
        "ddsource": "gaussdb",
        "dbm_type": "query_completion",
        "collection_interval": collection_interval,
        "ddtags": ddtags,
        "timestamp": timestamp_ms,
        "gaussdb_version": gaussdb_version,
        "cloud_metadata": cloud_metadata,
        "service": service,
        "gaussdb_query_completions": [{"query_details": details} for details in details_list],
    }


def build_plan_event(
    row: dict,
    *,
    host: str,
    database_instance: str,
    ddtags: str,
    obfuscated_statement: str,
    query_signature: str,
    obfuscated_plan: str | None,
    plan_signature: str | None,
    cloud_metadata: dict,
    service: Any,
    timestamp_ms: float,
) -> dict | None:
    """Build a dbm-samples plan event from the engine-stored plan.

    Returns None when the engine stored no plan for this execution, so callers never emit
    an empty plan envelope.
    """
    if not obfuscated_plan:
        return None
    return {
        "host": host,
        "database_instance": database_instance,
        "ddagentversion": datadog_agent.get_version(),
        "ddsource": "gaussdb",
        "dbm_type": "plan",
        "ddtags": ddtags,
        "timestamp": timestamp_ms,
        "cloud_metadata": cloud_metadata,
        "service": service,
        "duration": wall_duration_ms(row) * 1e6,
        "network": {
            "client": {
                "ip": str(row["client_addr"]) if row.get("client_addr") is not None else None,
                "port": row.get("client_port"),
            }
        },
        "db": {
            "instance": row.get("db_name"),
            "plan": {
                "definition": obfuscated_plan,
                "signature": plan_signature,
                # Read from a column, so there is no EXPLAIN failure to report.
                "collection_errors": None,
            },
            "query_signature": query_signature,
            "resource_hash": query_signature,
            "application": row.get("application_name"),
            "user": row.get("user_name"),
            "statement": obfuscated_statement,
        },
        # 引擎原生桶用 GaussDB 自己的名字：独有字段落在 @gaussdb.*，不借 openGauss 的命名空间。
        "gaussdb": native_columns(row),
    }


class GaussDBStatementHistory(DBMAsyncJob):
    """Incrementally ship completed slow SQL from dbe_perf.statement_history."""

    def __init__(self, check: GaussDb, config: InstanceConfig):
        collection_interval = config.statement_history.collection_interval
        super(GaussDBStatementHistory, self).__init__(
            check,
            rate_limit=1 / collection_interval,
            run_sync=config.statement_history.run_sync,
            enabled=config.statement_history.enabled and config.dbm,
            dbms="gaussdb",
            min_collection_interval=config.min_collection_interval,
            expected_db_exceptions=(psycopg.errors.DatabaseError,),
            job_name="statement-history",
        )
        self._check = check
        self._config = config
        self._collection_interval = collection_interval
        self._batch_limit = config.statement_history.batch_limit
        # Boundary dedupe only. The cursor is strict (`finish_time > cursor`), so the sole
        # duplicate source is several rows sharing one finish_time across two passes.
        # A TTL cache expires entries instead of clearing wholesale at a size cap, which
        # would drop dedupe state for every in-flight boundary at once.
        self._seen_execution_ids = TTLCache(
            maxsize=config.statement_history.dedupe_cache_maxsize,
            ttl=max(collection_interval * 10, 60),
        )
        # Identical plan trees repeat across executions; ship each (query, plan) pair once
        # per hour the way the other engines rate-limit their plan streams.
        self._seen_plans = TTLCache(maxsize=config.statement_history.dedupe_cache_maxsize, ttl=3600)
        # Resolved on first collection from the engine's own catalog; see _discover_columns.
        self._columns = None
        # 一次性提醒的闸门：这几类问题按行重复刷日志毫无价值。
        self._warned_text_plan = False
        self._warned_plan_obfuscation = False
        self._warned_prerequisites = False
        obfuscate_options = self._config.obfuscator_options.model_dump()
        obfuscate_options["table_names"] = self._config.obfuscator_options.collect_tables
        obfuscate_options["dollar_quoted_func"] = self._config.obfuscator_options.keep_dollar_quoted_func
        obfuscate_options["return_json_metadata"] = self._config.obfuscator_options.collect_metadata
        obfuscate_options["dbms"] = "postgresql"
        self._obfuscate_options = to_native_string(json.dumps(obfuscate_options))

    def _shutdown(self):
        self._check = None

    # ── cursor ──

    def _load_cursor(self) -> datetime:
        cached = self._check.read_persistent_cache(CURSOR_CACHE_KEY)
        if not cached:
            return EPOCH
        try:
            return _as_utc(datetime.fromisoformat(cached))
        except ValueError:
            self._log.warning("Discarding unparseable statement_history cursor %r", cached)
            return EPOCH

    def _save_cursor(self, finish_time: datetime) -> None:
        self._check.write_persistent_cache(CURSOR_CACHE_KEY, finish_time.isoformat())

    # ── collection ──

    def _discover_columns(self, conn) -> list:
        """Read this engine's real column set once per process and cache it."""
        if self._columns is not None:
            return self._columns

        with conn.cursor() as db_cursor:
            db_cursor.execute(COLUMN_DISCOVERY_QUERY)
            available = [row[0] for row in db_cursor.fetchall()]

        if not available:
            raise psycopg.errors.UndefinedTable(
                "dbe_perf.statement_history exposes no columns — is the view present on this engine?"
            )

        missing_required = REQUIRED_COLUMNS - set(available)
        if missing_required:
            raise psycopg.errors.UndefinedColumn(
                "dbe_perf.statement_history is missing columns this collector cannot work without: "
                + ", ".join(sorted(missing_required))
            )

        columns = resolve_columns(available)
        absent = [c for c in STATEMENT_HISTORY_DESIRED_COLUMNS if c not in set(columns)]
        # Log the shortfall once at info: an operator comparing dashboards across engines
        # needs to know which fields are structurally absent rather than merely empty.
        self._log.info(
            "statement_history: selecting %d of %d desired columns; absent on this engine: %s",
            len(columns),
            len(STATEMENT_HISTORY_DESIRED_COLUMNS),
            ", ".join(absent) if absent else "none",
        )
        self._columns = columns
        return columns

    def _show_int(self, conn, query: str):
        """读一个整型 GUC；读不到返回 None（不让前置检查失败拖垮采集）。"""
        try:
            with conn.cursor() as db_cursor:
                db_cursor.execute(query)
                row = db_cursor.fetchone()
            return int(row[0]) if row else None
        except Exception:
            self._log.debug("statement_history: 读不到 %r，跳过该前置检查", query, exc_info=True)
            return None

    def _check_engine_prerequisites(self, conn) -> None:
        """开采集前查两个前置条件，不满足时 loud 提醒。

        这是「链路全绿但数据没意义」的唯一可见信号，所以两条都给出可直接执行的处置。
        """
        if self._warned_prerequisites:
            return
        self._warned_prerequisites = True

        # ① unique SQL 槽位——最常踩的那个。打满后 query 被换成提示串，整批行没有可用签名。
        cap = self._show_int(conn, UNIQUE_SQL_COUNT_QUERY)
        used = self._show_int(conn, UNIQUE_SQL_OCCUPANCY_QUERY)
        if cap and used is not None and used >= cap * UNIQUE_SQL_OCCUPANCY_WARN_RATIO:
            self._log.warning(
                "statement_history: unique SQL 槽位 %d/%d 已近满或打满——超出后内核不再为新语句"
                "登记 unique SQL，query 被回填成 %r 而不是真 SQL，这些行没有可用签名只能整行丢弃"
                "（507.0.0 实测：4887/4887 行如此，分阶段耗时仍有值）。处置：调大 "
                "instr_unique_sql_count（默认 100，官方建议 200000）。",
                used,
                cap,
                MISSING_SQL_HINT,
            )

        # ② 慢 SQL 档位。只有 OFF 才是问题——507.0.0 在 'OFF,L0' 之下 query / query_plan /
        # 分阶段耗时全部有值，L0 已足够。
        try:
            with conn.cursor() as db_cursor:
                db_cursor.execute(STAT_LEVEL_QUERY)
                row = db_cursor.fetchone()
        except Exception:
            self._log.debug("statement_history: 读不到 track_stmt_stat_level，跳过档位检查", exc_info=True)
            return
        if not row:
            return
        setting = str(row[0])
        level = slow_stat_level(setting)
        if level in INSUFFICIENT_SLOW_STAT_LEVELS:
            self._log.warning(
                "statement_history: track_stmt_stat_level=%r，慢 SQL 档位为 %s——该档位下引擎"
                "一行都不写。处置：把第二段设为 L0（实测 'OFF,L0' 即可拿到 query / query_plan / "
                "全部分阶段耗时）。",
                setting,
                level,
            )
        else:
            self._log.debug(
                "statement_history: track_stmt_stat_level=%r（慢 SQL 档位 %s，足够）", setting, level
            )

    def _fetch_rows(self, cursor: datetime):
        with self._check.db_pool.get_connection(self._config.dbname) as conn:
            columns = self._discover_columns(conn)
            self._check_engine_prerequisites(conn)
            query = STATEMENT_HISTORY_QUERY.format(columns=", ".join(columns))
            with conn.cursor(row_factory=dict_row) as db_cursor:
                db_cursor.execute(query, (cursor, self._batch_limit))
                return db_cursor.fetchall()

    def _dbtags(self, db_name) -> list:
        tags = [t for t in self._tags if not t.startswith("db:")]
        if db_name:
            tags.append("db:{}".format(db_name))
        return tags

    def _obfuscate(self, row: dict):
        statement = obfuscate_sql_with_metadata(row["query"], self._obfuscate_options)
        obfuscated_query = statement["query"]
        query_signature = compute_sql_signature(obfuscated_query)
        obfuscated_plan, plan_signature = None, None
        query_plan = row.get("query_plan")
        if not has_recorded_plan(query_plan):
            pass
        elif looks_like_json_plan(query_plan):
            try:
                obfuscated_plan = datadog_agent.obfuscate_sql_exec_plan(query_plan)
                normalized_plan = datadog_agent.obfuscate_sql_exec_plan(query_plan, normalize=True)
                plan_signature = compute_exec_plan_signature(normalized_plan)
            except Exception:
                # 计划字段降级为空，其余列照常上报。判形是启发式，早晚会被没见过的
                # query_plan 形态再骗一次；真正兜住的是这一层——计划脱敏失败只丢计划，
                # 不能把 statement / query_signature / 各阶段耗时 / 锁计数一起连坐。
                obfuscated_plan, plan_signature = None, None
                if not self._warned_plan_obfuscation:
                    self._warned_plan_obfuscation = True
                    self._log.exception(
                        "statement_history: query_plan 脱敏失败，本行只丢计划字段、"
                        "其余列照常上报（同类失败后续不再重复记录）"
                    )
        elif not self._warned_text_plan:
            # 文本计划无法经 JSON 脱敏器处理，而原文可能带 Index Cond / Filter 里的字面量，
            # 直接上报会漏敏。故不产出 plan 事件，只提醒一次；completion 事件本身不受影响。
            self._warned_text_plan = True
            self._log.warning(
                "statement_history: query_plan 是文本格式而非 JSON，跳过 plan 事件上报"
                "（completion 事件不受影响）。文本计划无法经 JSON 脱敏器处理，"
                "原样上报会带出 Index Cond / Filter 里的字面量。"
            )
        return obfuscated_query, query_signature, obfuscated_plan, plan_signature, statement.get("metadata") or {}

    @tracked_method(agent_check_getter=agent_check_getter)
    def run_job(self):
        cursor = self._load_cursor()
        rows = self._fetch_rows(cursor)
        if not rows:
            self._log.debug("No new completed slow SQL past cursor %s", cursor)
            return

        timestamp_ms = time.time() * 1000
        details_list = []
        plan_events = []
        skipped_no_statement = 0
        for row in rows:
            # 两种没有可用 SQL 文本的行都要跳过：空串（引擎没写），以及 unique SQL 槽位打满时
            # 内核回填的提示串。后者更隐蔽——它非空，不跳的话所有行会用同一句提示串算出
            # 同一个签名，把整条流污染成"一个超慢查询被执行了几千次"。
            statement_text = (row.get("query") or "").strip()
            if not statement_text or is_missing_sql_hint(statement_text):
                skipped_no_statement += 1
                continue
            execution_id = row.get("debug_query_id")
            if execution_id is not None and execution_id in self._seen_execution_ids:
                continue
            if execution_id is not None:
                self._seen_execution_ids[execution_id] = True
            try:
                statement, query_signature, plan, plan_signature, metadata = self._obfuscate(row)
            except Exception:
                self._log.exception("Failed to obfuscate statement_history row, skipping it")
                continue

            details = completion_row_details(
                row, obfuscated_statement=statement, query_signature=query_signature
            )
            details["metadata"] = {
                "tables": metadata.get("tables"),
                "commands": metadata.get("commands"),
                "comments": metadata.get("comments"),
            }
            details_list.append(details)

            plan_key = (query_signature, plan_signature)
            if plan_signature and plan_key not in self._seen_plans:
                self._seen_plans[plan_key] = True
                event = build_plan_event(
                    row,
                    host=self._check.reported_hostname,
                    database_instance=self._check.database_identifier,
                    ddtags=",".join(self._dbtags(row.get("db_name"))),
                    obfuscated_statement=statement,
                    query_signature=query_signature,
                    obfuscated_plan=plan,
                    plan_signature=plan_signature,
                    cloud_metadata=self._check.cloud_metadata,
                    service=self._config.service,
                    timestamp_ms=timestamp_ms,
                )
                if event is not None:
                    event["db"]["metadata"] = details["metadata"]
                    plan_events.append(event)

        # Plans first: a completion event referencing a plan_signature should not land
        # before the plan it points at.
        for event in plan_events:
            self._check.database_monitoring_query_sample(
                json.dumps(event, default=default_json_event_encoding)
            )

        if details_list:
            payload = build_completion_payload(
                details_list,
                host=self._check.reported_hostname,
                database_instance=self._check.database_identifier,
                # A list, matching what ClickHouse and SQL Server put on the activity
                # intake; the per-row plan events keep the comma-joined samples form.
                ddtags=self._dbtags(None),
                collection_interval=self._collection_interval,
                gaussdb_version=self._check.gaussdb_version or self._check.raw_version or "",
                cloud_metadata=self._check.cloud_metadata,
                service=self._config.service,
                timestamp_ms=timestamp_ms,
            )
            self._check.database_monitoring_query_activity(
                json.dumps(payload, default=default_json_event_encoding)
            )

        self._save_cursor(max_finish_time(rows, cursor))

        self._check.count(
            "dd.gaussdb.statement_history.completions_submitted.count",
            len(details_list),
            tags=self._tags + self._check._get_debug_tags(),
            hostname=self._check.reported_hostname,
            raw=True,
        )
        if skipped_no_statement:
            self._log.warning(
                "statement_history: 本轮 %d/%d 行没有可用 SQL 文本被跳过——最常见原因是 "
                "instr_unique_sql_count 槽位打满（引擎回填 %r 代替真 SQL）",
                skipped_no_statement,
                len(rows),
                MISSING_SQL_HINT,
            )
        self._check.count(
            "dd.gaussdb.statement_history.rows_missing_statement.count",
            skipped_no_statement,
            tags=self._tags + self._check._get_debug_tags(),
            hostname=self._check.reported_hostname,
            raw=True,
        )
        self._check.count(
            "dd.gaussdb.statement_history.plans_submitted.count",
            len(plan_events),
            tags=self._tags + self._check._get_debug_tags(),
            hostname=self._check.reported_hostname,
            raw=True,
        )
