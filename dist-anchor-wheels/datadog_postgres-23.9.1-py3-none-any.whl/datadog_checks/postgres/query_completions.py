# (C) Datadog, Inc. 2026-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
"""Collect completed slow SQL from the ``auto_explain`` JSON log as DBM events.

PostgreSQL has no server-side history of finished executions. ``pg_stat_statements``
aggregates, ``pg_stat_activity`` samples what is running now, and neither can answer "show me
the individual statement that took 5 seconds at 01:58:44". The only per-execution record the
engine produces is the one it writes to its log, so that is the source here: ``auto_explain``
with ``log_format = json``, which emits the SQL text, the plan the executor actually ran, and
its buffer counters for every statement over ``auto_explain.log_min_duration``.

The shape mirrors the openGauss ``statement_history`` collector -- ``DBMAsyncJob``, a
persistent read position, a ``query_completion`` batch on the dbm-activity track and a
``plan`` event on the dbm-samples track -- and differs in the three places the source forces
it to:

* the source is a file, so a pass reads bytes rather than rows;
* the position is a file offset qualified by device, inode and a first-line signature rather
  than a monotonic column, because log files rotate, get truncated in place and get reused;
* nothing is discovered at runtime from a catalog. The JSON is self-describing.

Only ``auto_explain`` records become completions. ``log_min_duration_statement`` writes its
own ``duration: N ms  statement:`` / ``execute`` line for the same execution whenever it is
the coarser of the two thresholds, and those lines are deliberately ignored -- see
``DURATION_PLAN_PATTERN`` below for why pairing them is not sound.
"""

from __future__ import annotations

import glob as globlib
import hashlib
import os
import re
import time
from dataclasses import dataclass, replace  # noqa: F401  (re-exported for record rewriting)
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any
from zoneinfo import ZoneInfo

import psycopg
from cachetools import TTLCache

from datadog_checks.base.utils.common import to_native_string
from datadog_checks.base.utils.db.sql import compute_exec_plan_signature, compute_sql_signature
from datadog_checks.base.utils.db.utils import (
    DBMAsyncJob,
    default_json_event_encoding,
    obfuscate_sql_with_metadata,
)
from datadog_checks.base.utils.serialization import json
from datadog_checks.base.utils.tracking import tracked_method
from datadog_checks.postgres.statement_samples import agent_check_getter

try:
    import datadog_agent
except ImportError:
    from datadog_checks.base.stubs import datadog_agent

if TYPE_CHECKING:
    from datadog_checks.postgres import PostgreSql
    from datadog_checks.postgres.config_models import InstanceConfig

__all__ = ["PostgresQueryCompletions"]

POSITION_CACHE_KEY = "query_completions_log_position"

# A log record starts on a line that begins with a timestamp; everything else -- the tab
# indented JSON body, echoed multi-line SQL, DETAIL continuations -- belongs to the record
# above it. This is the same boundary the shipped `logs` configuration uses for its
# `multi_line` rule, so the two consumers of this file agree on where records begin.
RECORD_START_PATTERN = re.compile(rb"(?m)^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}")

# ``auto_explain`` writes ``duration: <ms> ms  plan:`` followed by the JSON body.
#
# ``log_min_duration_statement`` writes ``duration: <ms> ms  statement: <sql>`` (simple
# protocol) or ``... execute <unnamed>: <sql>`` (extended protocol) for the same execution
# when it is the coarser threshold, which is the recommended configuration. Those lines are
# never a completion source, because the two records cannot be paired reliably. Measured over
# a full day on a benchbase host (2026-08-09, 86542 auto_explain records against 3181 plain
# ones): the two reported durations for one execution differ by up to 79 ms (p50 0.09 ms,
# p99 17.7 ms) since they measure different spans, the order is not fixed (2164 pairs logged
# the plan first, 533 last), and 484 plain records had no auto_explain counterpart at all.
# Any duration-window match therefore both misses real pairs and merges distinct executions.
# Reading only the auto_explain record makes double reporting structurally impossible.
DURATION_PLAN_PATTERN = re.compile(r"^duration: (?P<duration_ms>\d+(?:\.\d+)?) ms\s+plan:\s*$")

# This collector tails the server log itself instead of branching off the `logs` pipeline, so a
# host running both ships every auto_explain record twice -- once as a log line, once as a
# `query_completion` event. The shipped `logs` example carries an `exclude_at_match` rule to drop
# the half that becomes a completion; the pattern lives here so the two stay in step, and
# tests/test_query_completions.py pins the example to this constant.
#
# It has to stay narrower than `duration:`. `log_min_duration_statement` writes its own
# `duration: N ms  statement:` / `execute` line, which is never a completion source (see above),
# so for those executions the log line is the only record there is and it has to survive.
# RE2 -- the engine the Agent compiles this with -- has no lookaround, so keep to literals and
# character classes.
LOG_PIPELINE_EXCLUDE_PATTERN = r"LOG:\s+duration: [0-9.]+ ms\s+plan:"

# The Agent's own queries carry this marker; the postgres integration already uses it to keep
# them out of query metrics (see cursor.py and statements_v2.py).
DDIGNORE_MARKER = "/* DDIGNORE */"
AGENT_APPLICATION_NAME = "datadog-agent"

# How much of the file is hashed to tell one generation of a reused filename from the next.
FIRST_LINE_SIGNATURE_BYTES = 4096

# A single auto_explain record is normally a few kilobytes. This bound exists so a corrupt or
# absurdly large record cannot stall the read position forever.
MAX_RECORD_BYTES = 4 * 1024 * 1024

SERVER_SETTINGS = (
    "log_line_prefix",
    "log_timezone",
    "log_destination",
    "logging_collector",
    "log_directory",
    "log_filename",
    "data_directory",
    "log_min_duration_statement",
    "auto_explain.log_min_duration",
    "auto_explain.log_format",
)

SETTINGS_QUERY = "SELECT name, setting FROM pg_settings WHERE name = ANY(%s)"
CURRENT_LOGFILE_QUERY = "SELECT pg_current_logfile('stderr')"


class UnsupportedLogLinePrefix(Exception):
    """Raised when ``log_line_prefix`` cannot be turned into a usable record parser."""


# ── log_line_prefix ──

# A timestamp, with or without milliseconds and with or without a trailing zone. Covers %m,
# %t and %s, which differ only in precision.
TIMESTAMP_FRAGMENT = r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [A-Za-z0-9/_+-]+)?"

# Structured directives get a precise pattern; free-text ones get a lazy match and rely on the
# literal separators around them. Without the precise ones the lazy matches would slide.
PREFIX_DIRECTIVES = {
    "m": ("log_timestamp", TIMESTAMP_FRAGMENT),
    "t": ("log_timestamp", TIMESTAMP_FRAGMENT),
    "s": ("session_start_time", TIMESTAMP_FRAGMENT),
    "n": ("log_epoch", r"\d+(?:\.\d+)?"),
    "p": ("backend_pid", r"\d+"),
    "P": ("leader_pid", r"\d*"),
    "l": ("session_line_num", r"\d+"),
    "e": ("sql_state", r"[0-9A-Za-z]{5}"),
    "v": ("virtual_transaction_id", r"(?:\d+/\d+)?"),
    "x": ("transaction_id", r"\d+"),
    "c": ("session_id", r"[0-9a-f]+\.[0-9a-f]+"),
    "Q": ("plan_query_id", r"-?\d+"),
    "r": ("client", r".*?"),
    "h": ("client_host", r".*?"),
    "u": ("username", r".*?"),
    "d": ("database", r".*?"),
    "a": ("application_name", r".*?"),
    "b": ("backend_type", r".*?"),
    "i": ("command_tag", r".*?"),
}

# PostgreSQL writes ``<SEVERITY>:  <message>`` after the prefix. Anchoring on it is what lets
# the optional %q tail be resolved: for a background process there is no application name, so
# the tail has to be allowed to match nothing.
SEVERITY_FRAGMENT = r"(?P<severity>[A-Z][A-Z0-9]{1,9}):\s\s"

TIMESTAMP_ONLY_PATTERN = re.compile(r"^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?)")
CLIENT_PATTERN = re.compile(r"^(?P<addr>.+?)\((?P<port>\d+)\)$")


def compile_log_line_prefix(prefix: str) -> re.Pattern:
    """Turn a ``log_line_prefix`` into a regex that parses the first line of a record."""
    if not prefix or not prefix.startswith(("%m", "%t")):
        raise UnsupportedLogLinePrefix(
            "log_line_prefix must start with %m or %t: records are split on a leading timestamp, "
            "and without one a continuation line cannot be told apart from a new record. "
            "Got: {!r}".format(prefix)
        )

    head: list[str] = []
    tail: list[str] = []
    saw_q = False
    seen_groups: set[str] = set()
    index = 0
    while index < len(prefix):
        char = prefix[index]
        if char != "%":
            (tail if saw_q else head).append(re.escape(char))
            index += 1
            continue
        index += 1
        if index >= len(prefix):
            break
        directive = prefix[index]
        index += 1
        if directive == "%":
            (tail if saw_q else head).append("%")
            continue
        if directive == "q":
            saw_q = True
            continue
        name, fragment = PREFIX_DIRECTIVES.get(directive, (None, r".*?"))
        if name and name not in seen_groups:
            seen_groups.add(name)
            fragment = "(?P<{}>{})".format(name, fragment)
        else:
            fragment = "(?:{})".format(fragment)
        (tail if saw_q else head).append(fragment)

    body = "".join(head) + ("(?:{})?".format("".join(tail)) if saw_q else "".join(tail))
    return re.compile(body + SEVERITY_FRAGMENT)


# ── record splitting ──


def split_complete_records(
    chunk: bytes, *, flush_tail: bool = False, limit: int | None = None
) -> tuple[list[bytes], int]:
    """Split a chunk of log bytes into whole records.

    A record ends where the next one begins, so the last record in a file that is still being
    written may be incomplete -- a half-flushed JSON body looks exactly like a finished one.
    It is therefore withheld and its bytes are left unconsumed until the record after it
    arrives. ``flush_tail`` lifts that only for a file that can no longer grow.

    Returns the records and the number of bytes consumed, which is what the read position
    advances by. Bytes before the first record start are consumed but never returned: they are
    the tail of a record whose beginning was already read.
    """
    if not chunk:
        return [], 0
    starts = [m.start() for m in RECORD_START_PATTERN.finditer(chunk)]
    if not starts:
        return [], 0
    count = len(starts) if flush_tail else len(starts) - 1
    if limit is not None:
        count = min(count, limit)
    if count <= 0:
        return [], starts[0]
    ends = starts[1:] + [len(chunk)]
    return [chunk[starts[i] : ends[i]] for i in range(count)], ends[count - 1]


# ── records ──


@dataclass
class AutoExplainRecord:
    """One completed execution as auto_explain wrote it."""

    duration_ms: float
    query_text: str
    plan: dict
    log_timestamp: datetime
    query_parameters: str | None = None
    query_id: int | None = None
    triggers: list | None = None
    jit: dict | None = None
    settings: dict | None = None
    username: str | None = None
    database: str | None = None
    application_name: str | None = None
    client_addr: str | None = None
    client_port: int | None = None
    backend_pid: int | None = None
    session_id: str | None = None
    session_line_num: int | None = None
    virtual_transaction_id: str | None = None
    transaction_id: int | None = None
    sql_state: str | None = None
    session_start_time: str | None = None


def blank_to_none(value: str | None) -> str | None:
    """PostgreSQL writes an empty field or ``[unknown]`` when it has no value to print."""
    if value is None:
        return None
    value = value.strip()
    return None if value in ("", "[unknown]") else value


def parse_int(value: str | None) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def parse_record(record: str, prefix_pattern: re.Pattern) -> AutoExplainRecord | None:
    """Parse one log record, or return None when it is not an auto_explain plan record."""
    first_line, _, body = record.partition("\n")
    match = prefix_pattern.match(first_line)
    if match is None:
        return None
    fields = match.groupdict()
    duration = DURATION_PLAN_PATTERN.match(first_line[match.end() :].strip())
    if duration is None:
        return None
    try:
        document = json.loads(body)
    except Exception:
        return None
    if not isinstance(document, dict):
        return None
    plan = document.get("Plan")
    if not isinstance(plan, dict):
        return None

    timestamp = TIMESTAMP_ONLY_PATTERN.match(fields.get("log_timestamp") or "")
    if timestamp is None:
        return None
    log_timestamp = datetime.fromisoformat(timestamp.group(1))

    client_addr, client_port = split_client(fields.get("client"))
    return AutoExplainRecord(
        duration_ms=float(duration.group("duration_ms")),
        query_text=document.get("Query Text") or "",
        plan=plan,
        log_timestamp=log_timestamp,
        query_parameters=document.get("Query Parameters"),
        query_id=document.get("Query Identifier"),
        triggers=document.get("Triggers"),
        jit=document.get("JIT"),
        settings=document.get("Settings"),
        username=blank_to_none(fields.get("username")),
        database=blank_to_none(fields.get("database")),
        application_name=blank_to_none(fields.get("application_name")),
        client_addr=client_addr,
        client_port=client_port,
        backend_pid=parse_int(fields.get("backend_pid")),
        session_id=blank_to_none(fields.get("session_id")),
        session_line_num=parse_int(fields.get("session_line_num")),
        virtual_transaction_id=blank_to_none(fields.get("virtual_transaction_id")),
        transaction_id=parse_int(fields.get("transaction_id")),
        sql_state=blank_to_none(fields.get("sql_state")),
        session_start_time=blank_to_none(fields.get("session_start_time")),
    )


def split_client(client: str | None) -> tuple[str | None, int | None]:
    """``%r`` is ``host(port)`` for TCP clients and ``[local]`` over a unix socket."""
    client = blank_to_none(client)
    if client is None:
        return None, None
    match = CLIENT_PATTERN.match(client)
    if match is None:
        return client, None
    return match.group("addr"), int(match.group("port"))


def record_id(record: AutoExplainRecord) -> str:
    """A stable identity for one log message.

    ``%c`` (session id) plus ``%l`` (per-session line number) names exactly one message:
    verified unique across all 86542 auto_explain records in a full day of production log.
    That makes it the key that absorbs a replay after the Agent dies between shipping a batch
    and writing the read position.
    """
    if record.session_id and record.session_line_num is not None:
        return "{}:{}".format(record.session_id, record.session_line_num)
    return "{}:{}:{}".format(record.backend_pid, record.session_line_num, record.log_timestamp)


def is_agent_query(record: AutoExplainRecord) -> bool:
    """Whether this execution is the Agent monitoring the database it is monitoring.

    Reporting these makes the Agent the top slow-query source on quiet instances and feeds its
    own overhead back into the data it collects.
    """
    return DDIGNORE_MARKER in (record.query_text or "") or record.application_name == AGENT_APPLICATION_NAME


# ── plan ──

# Counters worth lifting out of the root plan node. EXPLAIN reports buffer counters
# cumulatively -- a parent already includes its children -- so the root value is the total for
# the statement and summing the tree would multiply it.
PLAN_ROOT_FIELDS = (
    ("Node Type", "node_type"),
    ("Startup Cost", "startup_cost"),
    ("Total Cost", "total_cost"),
    ("Plan Rows", "plan_rows"),
    ("Plan Width", "plan_width"),
    ("Actual Rows", "actual_rows"),
    ("Actual Loops", "actual_loops"),
    ("Actual Startup Time", "actual_startup_time"),
    ("Actual Total Time", "actual_total_time"),
    ("Shared Hit Blocks", "shared_hit_blocks"),
    ("Shared Read Blocks", "shared_read_blocks"),
    ("Shared Dirtied Blocks", "shared_dirtied_blocks"),
    ("Shared Written Blocks", "shared_written_blocks"),
    ("Local Hit Blocks", "local_hit_blocks"),
    ("Local Read Blocks", "local_read_blocks"),
    ("Local Dirtied Blocks", "local_dirtied_blocks"),
    ("Local Written Blocks", "local_written_blocks"),
    ("Temp Read Blocks", "temp_read_blocks"),
    ("Temp Written Blocks", "temp_written_blocks"),
    ("WAL Records", "wal_records"),
    ("WAL FPI", "wal_fpi"),
    ("WAL Bytes", "wal_bytes"),
)


def plan_root_metrics(plan: dict) -> dict:
    """Roll the statement-level counters up from the root plan node.

    Absent keys are left out rather than defaulted. ``auto_explain.log_timing = off`` removes
    the per-node times entirely, and a zero there would read as "instant" instead of
    "not measured".
    """
    return {name: plan[key] for key, name in PLAN_ROOT_FIELDS if key in plan}


def plan_definition(record: AutoExplainRecord) -> str:
    """Serialize the plan in the shape ``EXPLAIN (FORMAT JSON)`` produces.

    statement_samples ships EXPLAIN output, a list of plan objects. Matching it keeps
    plan_signature comparable between the two collectors instead of splitting one query's
    plans across two encodings.

    ``Query Text`` and ``Query Parameters`` are dropped: the statement travels separately and
    already obfuscated, and the parameters are raw user data auto_explain happens to have
    written next to the plan.
    """
    entry: dict[str, Any] = {"Plan": record.plan}
    if record.settings:
        entry["Settings"] = record.settings
    if record.jit:
        entry["JIT"] = record.jit
    if record.triggers:
        entry["Triggers"] = record.triggers
    raw = json.dumps([entry])
    return raw.decode("utf-8") if isinstance(raw, bytes) else raw


def looks_like_json_plan(plan: str | None) -> bool:
    """Whether the plan can go through ``obfuscate_sql_exec_plan``.

    That obfuscator is a JSON scanner. Handing it anything else raises through the rtloader
    binding, and a caller that swallows the exception ends up dropping every record while the
    job keeps reporting success. The plan is rebuilt from parsed JSON here so this should
    always hold; it is checked because the failure mode is silent.
    """
    return (plan or "").lstrip()[:1] in ("{", "[")


# ── payloads ──


def to_utc(naive: datetime, log_timezone: str | None) -> datetime:
    """Resolve a log timestamp using the server's ``log_timezone``.

    The zone abbreviation printed in the log is not usable: on the reference host ``CST`` is
    China Standard Time, and the same three letters mean US Central elsewhere. Falling back to
    the Agent host's local zone is only correct because reading the log requires running on
    the database host.
    """
    zone = None
    if log_timezone:
        try:
            zone = ZoneInfo(log_timezone)
        except Exception:
            zone = None
    aware = naive.replace(tzinfo=zone) if zone is not None else naive.astimezone()
    return aware.astimezone(timezone.utc)


def native_fields(record: AutoExplainRecord) -> dict:
    """PostgreSQL's own view of the execution.

    Kept in its own namespace because the engines genuinely differ: PostgreSQL has a full plan
    tree with buffer counters but no cpu/parse/plan/data_io split, and openGauss has the split
    but usually an empty plan. Flattening them together would invent equivalences that do not
    exist.
    """
    fields = {
        "query_id": record.query_id,
        "backend_pid": record.backend_pid,
        "session_id": record.session_id,
        "session_line_num": record.session_line_num,
        "virtual_transaction_id": record.virtual_transaction_id,
        "transaction_id": record.transaction_id,
        "sql_state": record.sql_state,
        "session_start_time": record.session_start_time,
        "trigger_count": len(record.triggers) if record.triggers is not None else None,
    }
    fields.update(plan_root_metrics(record.plan))
    return {key: value for key, value in fields.items() if value is not None}


def completion_details(
    record: AutoExplainRecord,
    *,
    obfuscated_statement: str,
    query_signature: str,
    metadata: dict,
    log_timezone: str | None,
) -> dict:
    """Build one ``query_details`` block from an auto_explain record."""
    finish_time = to_utc(record.log_timestamp, log_timezone)
    start_time = finish_time - timedelta(milliseconds=record.duration_ms)
    details = {
        "statement": obfuscated_statement,
        "query_signature": query_signature,
        "duration_ms": record.duration_ms,
        "database_name": record.database,
        "username": record.username,
        "application_name": record.application_name,
        # auto_explain logs at executor end, so the log timestamp is the finish time and the
        # start is derived from it rather than guessed at collection time.
        "start_time": start_time.isoformat(),
        "finish_time": finish_time.isoformat(),
        "db_execution_id": record_id(record),
        "metadata": {
            "tables": metadata.get("tables"),
            "commands": metadata.get("commands"),
            "comments": metadata.get("comments"),
        },
        "postgres": native_fields(record),
    }
    if record.client_addr is not None:
        details["client_addr"] = record.client_addr
    if record.client_port is not None:
        details["client_port"] = record.client_port
    return details


def build_completion_payload(
    details_list: list,
    *,
    host: str,
    database_instance: str,
    ddtags: Any,
    collection_interval: float,
    postgres_version: str,
    cloud_metadata: dict,
    service: Any,
    timestamp_ms: float,
) -> dict:
    """Wrap query_details blocks in the dbm-activity completion envelope."""
    return {
        "host": host,
        "database_instance": database_instance,
        "ddagentversion": datadog_agent.get_version(),
        "ddsource": "postgres",
        "dbm_type": "query_completion",
        "collection_interval": collection_interval,
        "ddtags": ddtags,
        "timestamp": timestamp_ms,
        "postgres_version": postgres_version,
        "cloud_metadata": cloud_metadata,
        "service": service,
        "postgres_query_completions": [{"query_details": details} for details in details_list],
    }


def build_plan_event(
    record: AutoExplainRecord,
    *,
    host: str,
    database_instance: str,
    ddtags: str,
    obfuscated_statement: str,
    query_signature: str,
    obfuscated_plan: str | None,
    plan_signature: str | None,
    metadata: dict,
    cloud_metadata: dict,
    service: Any,
    timestamp_ms: float,
) -> dict | None:
    """Build a dbm-samples plan event from the plan the executor actually ran."""
    if not obfuscated_plan:
        return None
    return {
        "host": host,
        "database_instance": database_instance,
        "ddagentversion": datadog_agent.get_version(),
        "ddsource": "postgres",
        "dbm_type": "plan",
        "ddtags": ddtags,
        "timestamp": timestamp_ms,
        "cloud_metadata": cloud_metadata,
        "service": service,
        "duration": record.duration_ms * 1e6,
        "network": {"client": {"ip": record.client_addr, "port": record.client_port}},
        "db": {
            "instance": record.database,
            "plan": {
                "definition": obfuscated_plan,
                "signature": plan_signature,
                # Read from the log, so there is no EXPLAIN that could have failed.
                "collection_errors": None,
            },
            "query_signature": query_signature,
            "resource_hash": query_signature,
            "application": record.application_name,
            "user": record.username,
            "statement": obfuscated_statement,
            "metadata": {
                "tables": metadata.get("tables"),
                "commands": metadata.get("commands"),
                "comments": metadata.get("comments"),
            },
        },
        "postgres": native_fields(record),
    }


# ── read position ──


@dataclass(frozen=True)
class LogPosition:
    """Where the last pass stopped, and in which file."""

    path: str
    dev: int
    inode: int
    offset: int
    signature: str | None

    def serialize(self) -> str:
        raw = json.dumps(
            {
                "path": self.path,
                "dev": self.dev,
                "inode": self.inode,
                "offset": self.offset,
                "signature": self.signature,
            }
        )
        return raw.decode("utf-8") if isinstance(raw, bytes) else raw

    @classmethod
    def deserialize(cls, raw: str | None) -> LogPosition | None:
        if not raw:
            return None
        try:
            data = json.loads(raw)
            return cls(
                path=data["path"],
                dev=int(data["dev"]),
                inode=int(data["inode"]),
                offset=int(data["offset"]),
                signature=data.get("signature"),
            )
        except Exception:
            return None


def first_line_signature(path: str | os.PathLike) -> str | None:
    """Hash the first log line, which never changes for as long as the file lives.

    This is what distinguishes one generation of a reused filename from the next.
    ``log_filename = postgresql-%a.log`` with ``log_truncate_on_rotation`` comes back around
    every seven days on the same inode; if the Agent was down long enough for the new
    generation to grow past the stale offset, neither the inode nor the size reveals anything
    and a whole day of records would be skipped.

    Returns None while the first line is still incomplete, since hashing a partial line would
    produce a signature that changes on the next pass and force a full replay.
    """
    try:
        with open(path, "rb") as handle:
            head = handle.read(FIRST_LINE_SIGNATURE_BYTES)
    except OSError:
        return None
    end = head.find(b"\n")
    if end < 0:
        return None
    return hashlib.sha1(head[:end]).hexdigest()


def resume_offset(
    position: LogPosition | None,
    *,
    path: str,
    dev: int,
    inode: int,
    size: int,
    signature: str | None,
) -> int:
    """Decide where to start reading.

    Never seen this file: start at the end. A first run must not push the backlog of a
    multi-gigabyte daily log at the intake, and those records are already in the logs pipeline.
    """
    if position is None:
        return size
    if position.path != path or position.dev != dev or position.inode != inode:
        return 0
    if size < position.offset:
        return 0
    if signature and position.signature and signature != position.signature:
        return 0
    return position.offset


# ── job ──


class PostgresQueryCompletions(DBMAsyncJob):
    """Incrementally ship completed slow SQL from the auto_explain log."""

    def __init__(self, check: PostgreSql, config: InstanceConfig):
        collection_interval = config.query_completions.collection_interval
        super(PostgresQueryCompletions, self).__init__(
            check,
            rate_limit=1 / collection_interval,
            run_sync=config.query_completions.run_sync,
            enabled=config.query_completions.enabled and config.dbm,
            dbms="postgres",
            min_collection_interval=config.min_collection_interval,
            expected_db_exceptions=(psycopg.errors.DatabaseError,),
            job_name="query-completions",
        )
        self._check = check
        self._config = config
        self._settings_config = config.query_completions
        self._collection_interval = collection_interval
        # Absorbs a replay of bytes already shipped, which happens whenever the Agent stops
        # between handing a batch to the aggregator and writing the read position.
        self._seen_records = TTLCache(
            maxsize=config.query_completions.dedupe_cache_maxsize,
            ttl=max(collection_interval * 10, 300),
        )
        # Identical plan trees repeat across executions; ship each (query, plan) pair once per
        # hour the way the other engines rate limit their plan streams.
        self._seen_plans = TTLCache(maxsize=config.query_completions.dedupe_cache_maxsize, ttl=3600)
        self._warned: set[str] = set()
        self._prefix_source: str | None = None
        self._prefix_pattern: re.Pattern | None = None
        obfuscate_options = self._config.obfuscator_options.model_dump()
        obfuscate_options['table_names'] = self._config.obfuscator_options.collect_tables
        obfuscate_options['dollar_quoted_func'] = self._config.obfuscator_options.keep_dollar_quoted_func
        obfuscate_options['return_json_metadata'] = self._config.obfuscator_options.collect_metadata
        obfuscate_options['dbms'] = 'postgresql'
        self._obfuscate_options = to_native_string(json.dumps(obfuscate_options))

    def _shutdown(self):
        self._check = None

    def _warn_once(self, key: str, message: str, *args) -> None:
        if key in self._warned:
            return
        self._warned.add(key)
        self._log.warning(message, *args)

    # ── server side ──

    def _load_server_settings(self) -> dict | None:
        """Read the settings that describe the log, plus the file the server is writing."""
        settings: dict[str, str] = {}
        with self._check.db_pool.get_connection(self._config.dbname) as conn:
            with conn.cursor() as cursor:
                cursor.execute(SETTINGS_QUERY, (list(SERVER_SETTINGS),))
                for name, value in cursor.fetchall():
                    settings[name] = value
            try:
                with conn.cursor() as cursor:
                    cursor.execute(CURRENT_LOGFILE_QUERY)
                    row = cursor.fetchone()
                settings["current_logfile"] = row[0] if row else None
            except Exception:
                # Restricted to superusers and pg_monitor, and NULL when the collector is off.
                self._log.debug("query_completions: pg_current_logfile() unavailable", exc_info=True)
                settings["current_logfile"] = None
        return settings

    def _check_prerequisites(self, settings: dict) -> None:
        """Warn once for each server setting that makes this stream empty or unusable."""
        if "auto_explain.log_min_duration" not in settings:
            self._warn_once(
                "auto_explain_missing",
                "query_completions: auto_explain is not loaded, so PostgreSQL writes no per-execution "
                "plans and this stream stays empty. PostgreSQL has no server-side history of finished "
                "statements, so there is no other source. Load it with "
                "shared_preload_libraries = 'auto_explain' (or session_preload_libraries to avoid a "
                "restart) and set auto_explain.log_min_duration and auto_explain.log_format = json.",
            )
            return

        log_format = (settings.get("auto_explain.log_format") or "").lower()
        if log_format != "json":
            self._warn_once(
                "auto_explain_format",
                "query_completions: auto_explain.log_format is %r, so plans are unparseable here and "
                "cannot be obfuscated -- a text plan carries literals from its Filter conditions. "
                "Set auto_explain.log_format = json.",
                log_format or "unset",
            )

        threshold = parse_int(settings.get("auto_explain.log_min_duration"))
        statement_threshold = parse_int(settings.get("log_min_duration_statement"))
        if threshold is not None and threshold < 0:
            self._warn_once(
                "auto_explain_disabled",
                "query_completions: auto_explain.log_min_duration is -1, which disables plan logging. "
                "Set it to the slow threshold you want reported, in milliseconds.",
            )
        elif (
            threshold is not None
            and statement_threshold is not None
            and statement_threshold >= 0
            and threshold > statement_threshold
        ):
            self._warn_once(
                "auto_explain_above_statement",
                "query_completions: auto_explain.log_min_duration (%s ms) is above "
                "log_min_duration_statement (%s ms). Statements between the two thresholds are logged "
                "without a plan, and those plain lines are not a completion source, so they will not "
                "be reported. Set auto_explain.log_min_duration at or below "
                "log_min_duration_statement.",
                threshold,
                statement_threshold,
            )

    def _prefix_pattern_for(self, settings: dict) -> re.Pattern | None:
        prefix = settings.get("log_line_prefix") or ""
        if prefix == self._prefix_source and self._prefix_pattern is not None:
            return self._prefix_pattern
        try:
            pattern = compile_log_line_prefix(prefix)
        except UnsupportedLogLinePrefix as error:
            self._warn_once("prefix", "query_completions: unusable log_line_prefix -- %s", error)
            return None
        self._prefix_source = prefix
        self._prefix_pattern = pattern
        return pattern

    def _resolve_log_file(self, settings: dict) -> str | None:
        """Find the file the server is writing to."""
        configured = self._settings_config.log_file
        if configured:
            return configured

        data_directory = settings.get("data_directory") or ""
        current = settings.get("current_logfile")
        if current:
            return current if os.path.isabs(current) else os.path.join(data_directory, current)

        log_directory = settings.get("log_directory") or "log"
        if not os.path.isabs(log_directory):
            log_directory = os.path.join(data_directory, log_directory)
        log_filename = settings.get("log_filename") or "postgresql-%Y-%m-%d_%H%M%S.log"
        pattern = os.path.join(log_directory, re.sub(r"%.", "*", log_filename))
        candidates = [path for path in globlib.glob(pattern) if os.path.isfile(path)]
        if not candidates:
            self._warn_once(
                "no_log_file",
                "query_completions: cannot locate the server log file. pg_current_logfile() returned "
                "nothing (it needs pg_monitor and logging_collector = on) and no file matched %r. "
                "Set query_completions.log_file explicitly.",
                pattern,
            )
            return None
        return max(candidates, key=lambda path: os.stat(path).st_mtime)

    # ── collection ──

    @tracked_method(agent_check_getter=agent_check_getter)
    def run_job(self):
        settings = self._load_server_settings()
        if settings is None:
            return
        self._check_prerequisites(settings)
        prefix_pattern = self._prefix_pattern_for(settings)
        if prefix_pattern is None:
            return
        active_path = self._resolve_log_file(settings)
        if active_path is None:
            return

        position = LogPosition.deserialize(self._check.read_persistent_cache(POSITION_CACHE_KEY))

        # A file the server has rotated away from can still hold records written after the last
        # pass. Drain it before following the server to the new one, otherwise rotation quietly
        # loses up to one collection interval of slow queries every day.
        if position is not None and position.path != active_path and os.path.exists(position.path):
            if self._read_file(position.path, position, prefix_pattern, settings, is_active=False):
                return
            position = None

        if position is not None and position.path != active_path:
            position = None
        self._read_file(active_path, position, prefix_pattern, settings, is_active=True)

    def _read_file(
        self,
        path: str,
        position: LogPosition | None,
        prefix_pattern: re.Pattern,
        settings: dict,
        *,
        is_active: bool,
    ) -> int:
        """Read one bounded slice of a log file and ship what it holds.

        Returns the number of bytes consumed, which is zero when there was nothing new.
        """
        try:
            stat = os.stat(path)
        except OSError:
            self._warn_once(
                "missing:" + path,
                "query_completions: the server log file %s cannot be read. Check that the Agent user "
                "can read the log directory, or set query_completions.log_file.",
                path,
            )
            return 0
        self._warned.discard("missing:" + path)

        signature = first_line_signature(path)
        start = resume_offset(
            position,
            path=path,
            dev=stat.st_dev,
            inode=stat.st_ino,
            size=stat.st_size,
            signature=signature,
        )
        if position is None or start != position.offset:
            # Either a first sight of this file or a rotation: the dedupe cache is keyed on log
            # message identity, so a genuinely new generation cannot collide with it.
            self._log.debug("query_completions: reading %s from offset %s", path, start)

        budget = max(int(self._settings_config.max_bytes_per_run), 4096)
        limit = int(self._settings_config.batch_limit)
        with open(path, "rb") as handle:
            handle.seek(start)
            chunk = handle.read(budget)
            records, consumed = split_complete_records(chunk, flush_tail=False, limit=limit)
            # A record larger than one pass's byte budget would otherwise pin the offset
            # forever, so keep reading until a boundary appears or the hard bound is hit.
            while not consumed and start + len(chunk) < stat.st_size and len(chunk) < MAX_RECORD_BYTES:
                extra = handle.read(min(budget, MAX_RECORD_BYTES - len(chunk)))
                if not extra:
                    break
                chunk += extra
                records, consumed = split_complete_records(chunk, flush_tail=False, limit=limit)

        at_eof = start + len(chunk) >= stat.st_size
        if not is_active and at_eof:
            # Nothing more will ever be appended, so the last record is complete.
            records, consumed = split_complete_records(chunk, flush_tail=True, limit=limit)
        if not consumed and len(chunk) >= MAX_RECORD_BYTES:
            self._warn_once(
                "oversized:" + path,
                "query_completions: no record boundary within %s bytes of %s; skipping ahead.",
                MAX_RECORD_BYTES,
                path,
            )
            consumed = len(chunk)

        if records:
            self._process(records, prefix_pattern, settings)

        self._save_position(path, stat, start + consumed, signature)
        return consumed

    def _save_position(self, path: str, stat, offset: int, signature: str | None) -> None:
        self._check.write_persistent_cache(
            POSITION_CACHE_KEY,
            LogPosition(path=path, dev=stat.st_dev, inode=stat.st_ino, offset=offset, signature=signature).serialize(),
        )

    def _process(self, records: list, prefix_pattern: re.Pattern, settings: dict) -> None:
        log_timezone = settings.get("log_timezone")
        timestamp_ms = time.time() * 1000
        details_list = []
        plan_events = []
        agent_skipped = 0
        deduped = 0

        for raw in records:
            record = parse_record(raw.decode("utf-8", "replace"), prefix_pattern)
            if record is None:
                continue
            if self._settings_config.ignore_datadog_agent and is_agent_query(record):
                agent_skipped += 1
                continue
            identity = record_id(record)
            if identity in self._seen_records:
                deduped += 1
                continue
            self._seen_records[identity] = True

            try:
                statement, query_signature, plan, plan_signature, metadata = self._obfuscate(record)
            except Exception:
                self._log.exception("query_completions: failed to obfuscate a record, skipping it")
                continue

            details = completion_details(
                record,
                obfuscated_statement=statement,
                query_signature=query_signature,
                metadata=metadata,
                log_timezone=log_timezone,
            )
            details_list.append(details)

            plan_key = (query_signature, plan_signature)
            if plan_signature and plan_key not in self._seen_plans:
                self._seen_plans[plan_key] = True
                event = build_plan_event(
                    record,
                    host=self._check.reported_hostname,
                    database_instance=self._check.database_identifier,
                    ddtags=",".join(self._dbtags(record.database)),
                    obfuscated_statement=statement,
                    query_signature=query_signature,
                    obfuscated_plan=plan,
                    plan_signature=plan_signature,
                    metadata=metadata,
                    cloud_metadata=self._check.cloud_metadata,
                    service=self._config.service,
                    timestamp_ms=timestamp_ms,
                )
                if event is not None:
                    plan_events.append(event)

        # Plans first: a completion referencing a plan_signature should not land before the
        # plan it points at.
        for event in plan_events:
            self._check.database_monitoring_query_sample(json.dumps(event, default=default_json_event_encoding))

        if details_list:
            payload = build_completion_payload(
                details_list,
                host=self._check.reported_hostname,
                database_instance=self._check.database_identifier,
                ddtags=self._dbtags(None),
                collection_interval=self._collection_interval,
                postgres_version=self._check.raw_version or "",
                cloud_metadata=self._check.cloud_metadata,
                service=self._config.service,
                timestamp_ms=timestamp_ms,
            )
            self._check.database_monitoring_query_activity(json.dumps(payload, default=default_json_event_encoding))

        self._report_counts(len(details_list), len(plan_events), agent_skipped, deduped)

    def _report_counts(self, completions: int, plans: int, agent_skipped: int, deduped: int) -> None:
        tags = self._tags + self._check._get_debug_tags()
        for name, value in (
            ("completions_submitted", completions),
            ("plans_submitted", plans),
            ("agent_records_skipped", agent_skipped),
            ("records_deduped", deduped),
        ):
            self._check.count(
                "dd.postgres.query_completions.{}.count".format(name),
                value,
                tags=tags,
                hostname=self._check.reported_hostname,
                raw=True,
            )

    def _dbtags(self, db_name: str | None) -> list:
        tags = [t for t in self._tags if not t.startswith("db:")]
        if db_name:
            tags.append("db:{}".format(db_name))
        return tags

    def _obfuscate(self, record: AutoExplainRecord):
        statement = obfuscate_sql_with_metadata(record.query_text, self._obfuscate_options)
        obfuscated_query = statement["query"]
        query_signature = compute_sql_signature(obfuscated_query)
        obfuscated_plan, plan_signature = None, None
        try:
            raw_plan = plan_definition(record)
            if looks_like_json_plan(raw_plan):
                obfuscated_plan = datadog_agent.obfuscate_sql_exec_plan(raw_plan)
                normalized_plan = datadog_agent.obfuscate_sql_exec_plan(raw_plan, normalize=True)
                plan_signature = compute_exec_plan_signature(normalized_plan)
        except Exception:
            # Degrade the plan, keep the record. The caller's except is `skipping it`, so
            # letting this propagate drops the statement, the signature, the duration and
            # every other column along with the plan — GaussDB shipped exactly that bug and
            # its completion stream went to zero rows for 22 hours while the job kept
            # reporting success.
            obfuscated_plan, plan_signature = None, None
            self._warn_once(
                "plan-obfuscation",
                "query_completions: plan obfuscation failed; shipping the record without a "
                "plan. Later failures of this kind are not logged again.",
            )
        return obfuscated_query, query_signature, obfuscated_plan, plan_signature, statement.get("metadata") or {}
