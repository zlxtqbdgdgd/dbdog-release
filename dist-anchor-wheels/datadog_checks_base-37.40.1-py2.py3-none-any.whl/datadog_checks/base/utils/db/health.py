# (C) Datadog, Inc. 2025-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
# This is the base implementation of the Agent Health reporting system.
# It provides a structure for health events and codes that can be extended by specific checks.

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from cachetools import TLRUCache

from datadog_checks.base.utils.serialization import json

if TYPE_CHECKING:
    from datadog_checks.base import DatabaseCheck
try:
    import datadog_agent  # type: ignore
except ImportError:
    from datadog_checks.base.stubs import datadog_agent


import threading
import traceback
from enum import Enum


class HealthEvent(Enum):
    """
    Enum representing the health events.
    """

    INITIALIZATION = 'initialization'
    UNKNOWN_ERROR = 'unknown_error'
    MISSED_COLLECTION = 'missed_collection'


class HealthStatus(Enum):
    """
    Enum representing the health statuses for a given event.
    """

    OK = 'ok'
    WARNING = 'warning'
    ERROR = 'error'


DEFAULT_COOLDOWN = 60 * 5


def ttl(_key, value, now):
    return now + value


class Health:
    def __init__(self, check: DatabaseCheck):
        """
        Initialize the HealthCheck instance.

        :param check: AgentCheck
            The check instance that will be used to submit health events.
        """
        self.check = check
        self._cache_lock = threading.Lock()
        self._ttl_cache = TLRUCache(maxsize=1000, ttu=ttl)

    def submit_health_event(
        self,
        name: HealthEvent,
        status: HealthStatus,
        tags: list[str] = None,
        cooldown_time: int = None,
        cooldown_values: list[str] = None,
        data: dict = None,
    ):
        """
        Submit a health event to the aggregator.

        :param name: HealthEvent
            The name of the health event.
        :param status: HealthStatus
            The health status to submit.
        :param tags: list of str
            Tags to associate with the health event.
        :param cooldown_time: int
            The cooldown period in seconds to prevent the events with the same name and status
            from being submitted again. If None there is no cooldown.
        :param cooldown_values: list of str
            Additional values to include in the cooldown key.
        :param data: A dictionary to be submitted as `data`. Must be JSON serializable.
        """
        category = self.check.__NAMESPACE__ or self.check.__class__.__name__.lower()
        if cooldown_time:
            cooldown_key = "|".join([category, name.value, status.value])
            if cooldown_values:
                cooldown_key = "|".join([cooldown_key, "|".join([f"{v}" for v in cooldown_values])])
            with self._cache_lock:
                if self._ttl_cache.get(cooldown_key, None):
                    return
                self._ttl_cache[cooldown_key] = cooldown_time
        # utils 在模块层导入本模块的 HealthEvent，这里必须延迟导入才不成环。
        from datadog_checks.base.utils.db.utils import default_json_event_encoding

        # 冷却配额在提交之前就已扣掉，序列化一旦抛异常，这条事件不只是丢了，还会把
        # 后续同名事件静默压制整个冷却周期。data 由各集成自由填充（config 快照里可能
        # 出现 Decimal/datetime 之类），所以和其它 DBM 事件一样给一个编码兜底。
        self.check.event_platform_event(
            json.dumps(
                {
                    'timestamp': time.time() * 1000,
                    'version': 1,
                    'check_id': self.check.check_id,
                    'category': category,
                    'name': name,
                    'status': status,
                    'tags': tags or [],
                    'ddagentversion': datadog_agent.get_version(),
                    'ddagenthostname': datadog_agent.get_hostname(),
                    'data': data,
                },
                default=default_json_event_encoding,
            ),
            "dbm-health",
        )

    def submit_exception_health_event(self, exception: Exception, data: dict):
        trace = traceback.extract_tb(exception.__traceback__)
        exc = trace.pop()
        if exc:
            self.submit_health_event(
                name=HealthEvent.UNKNOWN_ERROR,
                status=HealthStatus.ERROR,
                data={
                    "file": exc.filename,
                    "line": exc.lineno,
                    "function": exc.name,
                    "exception_type": type(exception).__name__,
                    **(data or {}),
                },
            )
